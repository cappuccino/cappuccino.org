@STATIC;1.0;p;6;main.jI;23;Foundation/Foundation.jI;14;AppKit/CPCib.ji;14;NSFoundation.ji;10;NSAppKit.jc;2246;
importPackage(java.io);
CPLogRegister(CPLogPrint);
exec= function(command)
{
 var p = Packages.java.lang.Runtime.getRuntime().exec(jsArrayToJavaArray(command));
 var result = p.waitFor();
 var reader = new Packages.java.io.BufferedReader(new Packages.java.io.InputStreamReader(p.getInputStream()));
 while (s = reader.readLine())
  print(s);
 var reader = new Packages.java.io.BufferedReader(new Packages.java.io.InputStreamReader(p.getErrorStream()));
 while (s = reader.readLine())
  print(s);
 return result;
}
if (!(new Packages.java.io.File(args[0])).canRead())
{
    print("Could not read file at " + args[0]);
    return;
}
var temporaryNibFile = Packages.java.io.File.createTempFile("temp", ".nib"),
    temporaryNibFilePath = temporaryNibFile.getAbsolutePath();
temporaryNibFile.deleteOnExit();
if (exec(["/usr/bin/ibtool", args[0], "--compile", temporaryNibFilePath]))
{
    print("Could not compile file at " + args[0]);
    return;
}
var temporaryPlistFile = Packages.java.io.File.createTempFile("temp", ".plist"),
    temporaryPlistFilePath = temporaryPlistFile.getAbsolutePath();
temporaryPlistFile.deleteOnExit();
if (exec(["/usr/bin/plutil", "-convert", "xml1", temporaryNibFilePath, "-o", temporaryPlistFilePath]))
{
    print("Could not convert to xml plist for file at " + args[0]);
    return;
}
var data = objj_msgSend(CPURLConnection, "sendSynchronousRequest:returningResponse:error:", objj_msgSend(CPURLRequest, "requestWithURL:", temporaryPlistFilePath), nil, nil);
objj_msgSend(data, "setString:", objj_msgSend(data, "string").replace(/\<key\>\s*CF\$UID\s*\<\/key\>/g, "<key>CP$UID</key>"));
var unarchiver = objj_msgSend(objj_msgSend(CPKeyedUnarchiver, "alloc"), "initForReadingWithData:", data),
    objectData = objj_msgSend(unarchiver, "decodeObjectForKey:", "IB.objectdata"),
    data = objj_msgSend(CPData, "data"),
    archiver = objj_msgSend(objj_msgSend(CPKeyedArchiver, "alloc"), "initForWritingWithMutableData:", data);
objj_msgSend(archiver, "encodeObject:forKey:", objectData, "CPCibObjectDataKey");
objj_msgSend(archiver, "finishEncoding");
var writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("MainMenu.cib"), "UTF-8"));
writer.write(objj_msgSend(data, "string"));
writer.close();

p;10;NSAppKit.ji;10;NSButton.ji;8;NSCell.ji;9;NSColor.ji;13;NSColorWell.ji;11;NSControl.ji;16;NSCustomObject.ji;14;NSCustomView.ji;8;NSFont.ji;16;NSIBObjectData.ji;8;NSMenu.ji;12;NSMenuItem.ji;16;NSNibConnector.ji;15;NSPopUpButton.ji;13;NSResponder.ji;10;NSSlider.ji;13;NSSplitView.ji;13;NSTextField.ji;11;NSToolbar.ji;8;NSView.ji;18;NSWindowTemplate.ji;9;WebView.jc;251;
CP_NSMapClassName= function(aClassName)
{
    if (aClassName == "NSView")
        return "CPView";
    if (aClassName == "NSWindow")
        return "CPWindow";
    CPLog.warn("No class name mapping for \""+aClassName+"\"");
    return aClassName;
}

p;9;NSArray.jI;21;Foundation/CPObject.jc;636;
{var the_class = objj_allocateClassPair(CPObject, "NSArray"),
meta_class = the_class.isa;objj_registerClassPair(the_class);
objj_addClassForBundle(the_class, objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(the_class, [new objj_method(sel_getUid("initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    return objj_msgSend(aCoder, "_decodeArrayOfObjectsForKey:", "NS.objects");
}
})]);
}
{var the_class = objj_allocateClassPair(NSArray, "NSMutableArray"),
meta_class = the_class.isa;objj_registerClassPair(the_class);
objj_addClassForBundle(the_class, objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
}

p;10;NSButton.jI;17;AppKit/CPButton.ji;8;NSCell.ji;11;NSControl.jc;4445;
var _CPButtonBezelStyleHeights = {};
_CPButtonBezelStyleHeights[CPRoundedBezelStyle] = 18;
_CPButtonBezelStyleHeights[CPTexturedRoundedBezelStyle] = 20;
_CPButtonBezelStyleHeights[CPHUDBezelStyle] = 20;
{
var the_class = objj_getClass("CPButton")
if(!the_class) objj_exception_throw(new objj_exception(OBJJClassNotFoundException, "*** Could not find definition for class \"CPButton\""));
var meta_class = the_class.isa;class_addMethods(the_class, [new objj_method(sel_getUid("NS_initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    self = objj_msgSendSuper({ receiver:self, super_class:objj_getClass("CPButton").super_class }, "NS_initWithCoder:", aCoder);
    if (self)
    {
        _controlSize = CPRegularControlSize;
        var cell = objj_msgSend(aCoder, "decodeObjectForKey:", "NSCell");
        _title = objj_msgSend(cell, "title");
        _isBordered = objj_msgSend(cell, "isBordered");
        _bezelStyle = objj_msgSend(cell, "bezelStyle");
        switch (_bezelStyle)
        {
            case CPRoundedBezelStyle:
            case CPTexturedRoundedBezelStyle:
            case CPHUDBezelStyle:
                break;
            case CPRoundRectBezelStyle:
                _bezelStyle = CPRoundedBezelStyle;
                break;
            case CPSmallSquareBezelStyle:
            case CPThickSquareBezelStyle:
            case CPThickerSquareBezelStyle:
            case CPRegularSquareBezelStyle:
            case CPTexturedSquareBezelStyle:
            case CPShadowlessSquareBezelStyle:
                _bezelStyle = CPTexturedRoundedBezelStyle;
                break;
            case CPRecessedBezelStyle:
                _bezelStyle = CPHUDBezelStyle;
                break;
            case CPRoundedDisclosureBezelStyle:
            case CPHelpButtonBezelStyle:
            case CPCircularBezelStyle:
            case CPDisclosureBezelStyle:
                CPLog.warn("Unsupported bezel style: " + _bezelStyle);
                _bezelStyle = CPHUDBezelStyle;
                break;
            default:
                CPLog.error("Unknown bezel style: " + _bezelStyle);
                _bezelStyle = CPHUDBezelStyle;
        }
        if (_CPButtonBezelStyleHeights[_bezelStyle] != undefined)
        {
            CPLog.warn("Adjusting CPButton height from " +_frame.size.height+ " / " + _bounds.size.height+" to " + _CPButtonBezelStyleHeights[_bezelStyle]);
            _frame.size.height = _CPButtonBezelStyleHeights[_bezelStyle];
            _bounds.size.height = _CPButtonBezelStyleHeights[_bezelStyle];
        }
    }
    return self;
}
})]);
}
{var the_class = objj_allocateClassPair(CPButton, "NSButton"),
meta_class = the_class.isa;objj_registerClassPair(the_class);
objj_addClassForBundle(the_class, objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(the_class, [new objj_method(sel_getUid("initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    return objj_msgSend(self, "NS_initWithCoder:", aCoder);
}
}), new objj_method(sel_getUid("classForKeyedArchiver"), function(self, _cmd)
{ with(self)
{
    return objj_msgSend(CPButton, "class");
}
})]);
}
{var the_class = objj_allocateClassPair(NSActionCell, "NSButtonCell"),
meta_class = the_class.isa;class_addIvars(the_class, [new objj_ivar("_isBordered"), new objj_ivar("_bezelStyle"), new objj_ivar("_title")]);
objj_registerClassPair(the_class);
objj_addClassForBundle(the_class, objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(the_class, [new objj_method(sel_getUid("isBordered"), function(self, _cmd)
{ with(self)
{
return _isBordered;
}
}),
new objj_method(sel_getUid("bezelStyle"), function(self, _cmd)
{ with(self)
{
return _bezelStyle;
}
}),
new objj_method(sel_getUid("title"), function(self, _cmd)
{ with(self)
{
return _title;
}
}), new objj_method(sel_getUid("initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    self = objj_msgSendSuper({ receiver:self, super_class:objj_getClass("NSActionCell") }, "initWithCoder:", aCoder);
    if (self)
    {
        var buttonFlags = objj_msgSend(aCoder, "decodeIntForKey:", "NSButtonFlags"),
            buttonFlags2 = objj_msgSend(aCoder, "decodeIntForKey:", "NSButtonFlags2");
        _isBordered = (buttonFlags & 0x00800000) ? YES : NO;
        _bezelStyle = (buttonFlags2 & 0x7) | ((buttonFlags2 & 0x20) >> 2);
        _title = objj_msgSend(aCoder, "decodeObjectForKey:", "NSContents");
    }
    return self;
}
})]);
}

p;8;NSCell.jI;21;Foundation/CPObject.ji;8;NSFont.jc;4046;
{var the_class = objj_allocateClassPair(CPObject, "NSCell"),
meta_class = the_class.isa;class_addIvars(the_class, [new objj_ivar("_state"), new objj_ivar("_isHighlighted"), new objj_ivar("_isEnabled"), new objj_ivar("_isEditable"), new objj_ivar("_isBordered"), new objj_ivar("_isBezeled"), new objj_ivar("_isSelectable"), new objj_ivar("_isScrollable"), new objj_ivar("_isContinuous"), new objj_ivar("_wraps"), new objj_ivar("_alignment"), new objj_ivar("_controlSize"), new objj_ivar("_objectValue"), new objj_ivar("_font")]);
objj_registerClassPair(the_class);
objj_addClassForBundle(the_class, objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(the_class, [new objj_method(sel_getUid("state"), function(self, _cmd)
{ with(self)
{
return _state;
}
}),
new objj_method(sel_getUid("isHighlighted"), function(self, _cmd)
{ with(self)
{
return _isHighlighted;
}
}),
new objj_method(sel_getUid("isEnabled"), function(self, _cmd)
{ with(self)
{
return _isEnabled;
}
}),
new objj_method(sel_getUid("isEditable"), function(self, _cmd)
{ with(self)
{
return _isEditable;
}
}),
new objj_method(sel_getUid("isBordered"), function(self, _cmd)
{ with(self)
{
return _isBordered;
}
}),
new objj_method(sel_getUid("isBezeled"), function(self, _cmd)
{ with(self)
{
return _isBezeled;
}
}),
new objj_method(sel_getUid("isSelectable"), function(self, _cmd)
{ with(self)
{
return _isSelectable;
}
}),
new objj_method(sel_getUid("isScrollable"), function(self, _cmd)
{ with(self)
{
return _isScrollable;
}
}),
new objj_method(sel_getUid("isContinuous"), function(self, _cmd)
{ with(self)
{
return _isContinuous;
}
}),
new objj_method(sel_getUid("wraps"), function(self, _cmd)
{ with(self)
{
return _wraps;
}
}),
new objj_method(sel_getUid("alignment"), function(self, _cmd)
{ with(self)
{
return _alignment;
}
}),
new objj_method(sel_getUid("controlSize"), function(self, _cmd)
{ with(self)
{
return _controlSize;
}
}),
new objj_method(sel_getUid("objectValue"), function(self, _cmd)
{ with(self)
{
return _objectValue;
}
}),
new objj_method(sel_getUid("font"), function(self, _cmd)
{ with(self)
{
return _font;
}
}), new objj_method(sel_getUid("initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    self = objj_msgSendSuper({ receiver:self, super_class:objj_getClass("CPObject") }, "init");
    if (self)
    {
        var flags = objj_msgSend(aCoder, "decodeIntForKey:", "NSCellFlags"),
            flags2 = objj_msgSend(aCoder, "decodeIntForKey:", "NSCellFlags2");
        _state = (flags & 0x80000000) ? CPOnState : CPOffState;
        _isHighlighted = (flags & 0x40000000) ? YES : NO;
        _isEnabled = (flags & 0x20000000) ? NO : YES;
        _isEditable = (flags & 0x10000000) ? YES : NO;
        _isBordered = (flags & 0x00800000) ? YES : NO;
        _isBezeled = (flags & 0x00400000) ? YES : NO;
        _isSelectable = (flags & 0x00200000) ? YES : NO;
        _isScrollable = (flags & 0x00100000) ? YES : NO;
        _isContinuous = (flags & 0x00080100) ? YES : NO;
        _wraps = (flags & 0x00100000) ? NO : YES;
        _alignment = (flags2 & 0x1c000000) >> 26;
        _controlSize = (flags2 & 0xE0000) >> 17;
        _objectValue = objj_msgSend(aCoder, "decodeObjectForKey:", "NSContents");
        _font = objj_msgSend(aCoder, "decodeObjectForKey:", "NSFont");
    }
    return self;
}
}), new objj_method(sel_getUid("replacementObjectForCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    return nil;
}
}), new objj_method(sel_getUid("stringValue"), function(self, _cmd)
{ with(self)
{
    if (objj_msgSend(_objectValue, "isKindOfClass:", objj_msgSend(CPString, "class")))
        return _objectValue;
    if (objj_msgSend(_objectValue, "respondsToSelector:", sel_getUid("attributedStringValue")))
        return objj_msgSend(_objectValue, "attributedStringValue");
    return "";
}
})]);
}
{var the_class = objj_allocateClassPair(NSCell, "NSActionCell"),
meta_class = the_class.isa;objj_registerClassPair(the_class);
objj_addClassForBundle(the_class, objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
}

p;9;NSColor.jI;16;AppKit/CPColor.jc;1196;
var NSUnknownColorSpaceModel = -1,
    NSGrayColorSpaceModel = 0,
    NSRGBColorSpaceModel = 1,
    NSCMYKColorSpaceModel = 2,
    NSLABColorSpaceModel = 3,
    NSDeviceNColorSpaceModel = 4,
    NSIndexedColorSpaceModel = 5,
    NSPatternColorSpaceModel = 6;
{
var the_class = objj_getClass("CPColor")
if(!the_class) objj_exception_throw(new objj_exception(OBJJClassNotFoundException, "*** Could not find definition for class \"CPColor\""));
var meta_class = the_class.isa;class_addMethods(the_class, [new objj_method(sel_getUid("NS_initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    return self = objj_msgSend(CPColor, "blueColor");
}
})]);
}
{var the_class = objj_allocateClassPair(CPColor, "NSColor"),
meta_class = the_class.isa;objj_registerClassPair(the_class);
objj_addClassForBundle(the_class, objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(the_class, [new objj_method(sel_getUid("initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    return objj_msgSend(self, "NS_initWithCoder:", aCoder);
}
}), new objj_method(sel_getUid("classForKeyedArchiver"), function(self, _cmd)
{ with(self)
{
    return objj_msgSend(CPColor, "class");
}
})]);
}

p;13;NSColorWell.jI;20;AppKit/CPColorWell.ji;8;NSCell.ji;11;NSControl.jc;1276;
{
var the_class = objj_getClass("CPColorWell")
if(!the_class) objj_exception_throw(new objj_exception(OBJJClassNotFoundException, "*** Could not find definition for class \"CPColorWell\""));
var meta_class = the_class.isa;class_addMethods(the_class, [new objj_method(sel_getUid("NS_initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    self = objj_msgSendSuper({ receiver:self, super_class:objj_getClass("CPColorWell").super_class }, "NS_initWithCoder:", aCoder);
    if (self)
    {
        objj_msgSend(self, "setBordered:", objj_msgSend(aCoder, "decodeBoolForKey:", "NSIsBordered"));
        objj_msgSend(self, "setColor:", objj_msgSend(aCoder, "decodeBoolForKey:", "NSColor"));
    }
    return self;
}
})]);
}
{var the_class = objj_allocateClassPair(CPColorWell, "NSColorWell"),
meta_class = the_class.isa;objj_registerClassPair(the_class);
objj_addClassForBundle(the_class, objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(the_class, [new objj_method(sel_getUid("initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    return objj_msgSend(self, "NS_initWithCoder:", aCoder);
}
}), new objj_method(sel_getUid("classForKeyedArchiver"), function(self, _cmd)
{ with(self)
{
    return objj_msgSend(CPColorWell, "class");
}
})]);
}

p;11;NSControl.jI;18;AppKit/CPControl.ji;8;NSCell.ji;8;NSView.jc;1615;
{
var the_class = objj_getClass("CPControl")
if(!the_class) objj_exception_throw(new objj_exception(OBJJClassNotFoundException, "*** Could not find definition for class \"CPControl\""));
var meta_class = the_class.isa;class_addMethods(the_class, [new objj_method(sel_getUid("NS_initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    self = objj_msgSendSuper({ receiver:self, super_class:objj_getClass("CPControl").super_class }, "NS_initWithCoder:", aCoder);
    if (self)
    {
        objj_msgSend(self, "sendActionOn:", CPLeftMouseUpMask);
        var cell = objj_msgSend(aCoder, "decodeObjectForKey:", "NSCell");
        objj_msgSend(self, "setObjectValue:", objj_msgSend(cell, "objectValue"));
        objj_msgSend(self, "setFont:", objj_msgSend(cell, "font"));
        objj_msgSend(self, "setAlignment:", objj_msgSend(cell, "alignment"));
        objj_msgSend(self, "setEnabled:", objj_msgSend(aCoder, "decodeObjectForKey:", "NSEnabled"));
        objj_msgSend(self, "setContinuous:", objj_msgSend(cell, "isContinuous"));
    }
    return self;
}
})]);
}
{var the_class = objj_allocateClassPair(CPControl, "NSControl"),
meta_class = the_class.isa;objj_registerClassPair(the_class);
objj_addClassForBundle(the_class, objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(the_class, [new objj_method(sel_getUid("initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    return objj_msgSend(self, "NS_initWithCoder:", aCoder);
}
}), new objj_method(sel_getUid("classForKeyedArchiver"), function(self, _cmd)
{ with(self)
{
    return objj_msgSend(CPControl, "class");
}
})]);
}

p;16;NSCustomObject.jI;27;AppKit/_CPCibCustomObject.jc;1226;
{
var the_class = objj_getClass("_CPCibCustomObject")
if(!the_class) objj_exception_throw(new objj_exception(OBJJClassNotFoundException, "*** Could not find definition for class \"_CPCibCustomObject\""));
var meta_class = the_class.isa;class_addMethods(the_class, [new objj_method(sel_getUid("NS_initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    self = objj_msgSendSuper({ receiver:self, super_class:objj_getClass("_CPCibCustomObject").super_class }, "init");
    if (self){
        _className = objj_msgSend(aCoder, "decodeObjectForKey:", "NSClassName");
    print(":::"+_className);
    }
    return self;
}
})]);
}
{var the_class = objj_allocateClassPair(_CPCibCustomObject, "NSCustomObject"),
meta_class = the_class.isa;objj_registerClassPair(the_class);
objj_addClassForBundle(the_class, objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(the_class, [new objj_method(sel_getUid("initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{print("i-nit form coder");
    return objj_msgSend(self, "NS_initWithCoder:", aCoder);
}
}), new objj_method(sel_getUid("classForKeyedArchiver"), function(self, _cmd)
{ with(self)
{
    return objj_msgSend(_CPCibCustomObject, "class");
}
})]);
}

p;14;NSCustomView.jI;25;AppKit/_CPCibCustomView.ji;8;NSView.jc;1158;
var _CPCibCustomViewClassNameKey = "_CPCibCustomViewClassNameKey";
{var the_class = objj_allocateClassPair(CPView, "NSCustomView"),
meta_class = the_class.isa;class_addIvars(the_class, [new objj_ivar("_className")]);
objj_registerClassPair(the_class);
objj_addClassForBundle(the_class, objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(the_class, [new objj_method(sel_getUid("initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    self = objj_msgSendSuper({ receiver:self, super_class:objj_getClass("CPView") }, "NS_initWithCoder:", aCoder);
    if (self)
        _className = objj_msgSend(aCoder, "decodeObjectForKey:", "NSClassName");
    return self;
}
}), new objj_method(sel_getUid("encodeWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    objj_msgSendSuper({ receiver:self, super_class:objj_getClass("CPView") }, "encodeWithCoder:", aCoder);
    objj_msgSend(aCoder, "encodeObject:forKey:", CP_NSMapClassName(_className), _CPCibCustomViewClassNameKey);
}
}), new objj_method(sel_getUid("classForKeyedArchiver"), function(self, _cmd)
{ with(self)
{
    return objj_msgSend(_CPCibCustomView, "class");
}
})]);
}

p;8;NSFont.jI;15;AppKit/CPFont.jc;1051;
{
var the_class = objj_getClass("CPFont")
if(!the_class) objj_exception_throw(new objj_exception(OBJJClassNotFoundException, "*** Could not find definition for class \"CPFont\""));
var meta_class = the_class.isa;class_addMethods(the_class, [new objj_method(sel_getUid("NS_initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    return objj_msgSend(self, "_initWithName:size:bold:", objj_msgSend(aCoder, "decodeObjectForKey:", "NSName"), objj_msgSend(aCoder, "decodeDoubleForKey:", "NSSize"), NO);
}
})]);
}
{var the_class = objj_allocateClassPair(CPFont, "NSFont"),
meta_class = the_class.isa;objj_registerClassPair(the_class);
objj_addClassForBundle(the_class, objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(the_class, [new objj_method(sel_getUid("initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    return objj_msgSend(self, "NS_initWithCoder:", aCoder);
}
}), new objj_method(sel_getUid("classForKeyedArchiver"), function(self, _cmd)
{ with(self)
{
    return objj_msgSend(CPFont, "class");
}
})]);
}

p;14;NSFoundation.ji;9;NSArray.jp;16;NSIBObjectData.jI;21;Foundation/CPObject.jI;25;AppKit/_CPCibObjectData.jc;2111;
{
var the_class = objj_getClass("_CPCibObjectData")
if(!the_class) objj_exception_throw(new objj_exception(OBJJClassNotFoundException, "*** Could not find definition for class \"_CPCibObjectData\""));
var meta_class = the_class.isa;class_addMethods(the_class, [new objj_method(sel_getUid("NS_initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    self = objj_msgSend(self, "init");
    if (self)
    {
        _namesKeys = objj_msgSend(aCoder, "decodeObjectForKey:", "NSNamesKeys");
        _namesValues = objj_msgSend(aCoder, "decodeObjectForKey:", "NSNamesValues");
        _classesKeys = objj_msgSend(aCoder, "decodeObjectForKey:", "NSClassesKeys");print("d");
        _classesValues = objj_msgSend(aCoder, "decodeObjectForKey:", "NSClassesValues");print("e");
        _connections = objj_msgSend(aCoder, "decodeObjectForKey:", "NSConnections");
        _framework = objj_msgSend(aCoder, "decodeObjectForKey:", "NSFramework");
        _nextOid = objj_msgSend(aCoder, "decodeIntForKey:", "NSNextOid");
        _objectsKeys = objj_msgSend(aCoder, "decodeObjectForKey:", "NSObjectsKeys");
        _objectsValues = objj_msgSend(aCoder, "decodeObjectForKey:", "NSObjectsValues");
        _oidKeys = objj_msgSend(aCoder, "decodeObjectForKey:", "NSOidsKeys");
        _oidValues = objj_msgSend(aCoder, "decodeObjectForKey:", "NSOidsValues");
        _fileOwner = objj_msgSend(aCoder, "decodeObjectForKey:", "NSRoot");
        _visibleWindows = objj_msgSend(aCoder, "decodeObjectForKey:", "NSVisibleWindows");
    }
    return self;
}
})]);
}
{var the_class = objj_allocateClassPair(_CPCibObjectData, "NSIBObjectData"),
meta_class = the_class.isa;objj_registerClassPair(the_class);
objj_addClassForBundle(the_class, objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(the_class, [new objj_method(sel_getUid("initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    return objj_msgSend(self, "NS_initWithCoder:", aCoder);
}
}), new objj_method(sel_getUid("classForKeyedArchiver"), function(self, _cmd)
{ with(self)
{
    return objj_msgSend(_CPCibObjectData, "class");
}
})]);
}

p;8;NSMenu.jI;15;AppKit/CPMenu.ji;12;NSMenuItem.jc;1177;
{
var the_class = objj_getClass("CPMenu")
if(!the_class) objj_exception_throw(new objj_exception(OBJJClassNotFoundException, "*** Could not find definition for class \"CPMenu\""));
var meta_class = the_class.isa;class_addMethods(the_class, [new objj_method(sel_getUid("NS_initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    self = objj_msgSendSuper({ receiver:self, super_class:objj_getClass("CPMenu").super_class }, "init");
    if (self)
    {
        _title = objj_msgSend(aCoder, "decodeObjectForKey:", "NSTitle");
        _items = objj_msgSend(aCoder, "decodeObjectForKey:", "NSMenuItems");
    }
    return self;
}
})]);
}
{var the_class = objj_allocateClassPair(CPMenu, "NSMenu"),
meta_class = the_class.isa;objj_registerClassPair(the_class);
objj_addClassForBundle(the_class, objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(the_class, [new objj_method(sel_getUid("initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    return objj_msgSend(self, "NS_initWithCoder:", aCoder);
}
}), new objj_method(sel_getUid("classForKeyedArchiver"), function(self, _cmd)
{ with(self)
{
    return objj_msgSend(CPMenu, "class");
}
})]);
}

p;12;NSMenuItem.jI;19;AppKit/CPMenuItem.ji;8;NSMenu.jc;1802;
{
var the_class = objj_getClass("CPMenuItem")
if(!the_class) objj_exception_throw(new objj_exception(OBJJClassNotFoundException, "*** Could not find definition for class \"CPMenuItem\""));
var meta_class = the_class.isa;class_addMethods(the_class, [new objj_method(sel_getUid("NS_initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    self = objj_msgSendSuper({ receiver:self, super_class:objj_getClass("CPMenuItem").super_class }, "init");
    if (self)
    {
        _title = objj_msgSend(aCoder, "decodeObjectForKey:", "NSTitle");
        _target = objj_msgSend(aCoder, "decodeObjectForKey:", "NSTarget");
        _action = objj_msgSend(aCoder, "decodeObjectForKey:", "NSAction");
        _isEnabled = !objj_msgSend(aCoder, "decodeBoolForKey:", "NSIsDisabled");
        _isHidden = objj_msgSend(aCoder, "decodeBoolForKey:", "NSIsHidden");
        _submenu = objj_msgSend(aCoder, "decodeObjectForKey:", "NSSubmenu");
        _menu = objj_msgSend(aCoder, "decodeObjectForKey:", "NSMenu");
    }
    return self;
}
})]);
}
{var the_class = objj_allocateClassPair(CPMenuItem, "NSMenuItem"),
meta_class = the_class.isa;objj_registerClassPair(the_class);
objj_addClassForBundle(the_class, objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(the_class, [new objj_method(sel_getUid("initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    return objj_msgSend(self, "NS_initWithCoder:", aCoder);
}
}), new objj_method(sel_getUid("classForKeyedArchiver"), function(self, _cmd)
{ with(self)
{
    return objj_msgSend(CPMenuItem, "class");
}
})]);
}
{var the_class = objj_allocateClassPair(NSButtonCell, "NSMenuItemCell"),
meta_class = the_class.isa;objj_registerClassPair(the_class);
objj_addClassForBundle(the_class, objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
}

p;16;NSNibConnector.jI;24;AppKit/_CPCibConnector.jc;2609;
{
var the_class = objj_getClass("_CPCibConnector")
if(!the_class) objj_exception_throw(new objj_exception(OBJJClassNotFoundException, "*** Could not find definition for class \"_CPCibConnector\""));
var meta_class = the_class.isa;class_addMethods(the_class, [new objj_method(sel_getUid("NS_initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    self = objj_msgSendSuper({ receiver:self, super_class:objj_getClass("_CPCibConnector").super_class }, "init");
    if (self)
    {
        _source = objj_msgSend(aCoder, "decodeObjectForKey:", "NSSource");
        _destination = objj_msgSend(aCoder, "decodeObjectForKey:", "NSDestination");
        _label = objj_msgSend(aCoder, "decodeObjectForKey:", "NSLabel");
        CPLog.debug("Connection: " + objj_msgSend(_source, "description") + " " + objj_msgSend(_destination, "description") + " " + _label);
    }
    return self;
}
})]);
}
{var the_class = objj_allocateClassPair(_CPCibConnector, "NSNibConnector"),
meta_class = the_class.isa;objj_registerClassPair(the_class);
objj_addClassForBundle(the_class, objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(the_class, [new objj_method(sel_getUid("initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    return objj_msgSend(self, "NS_initWithCoder:", aCoder);
}
}), new objj_method(sel_getUid("classForKeyedArchiver"), function(self, _cmd)
{ with(self)
{
    return objj_msgSend(_CPCibConnector, "class");
}
})]);
}
{var the_class = objj_allocateClassPair(_CPCibControlConnector, "NSNibControlConnector"),
meta_class = the_class.isa;objj_registerClassPair(the_class);
objj_addClassForBundle(the_class, objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(the_class, [new objj_method(sel_getUid("initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    return objj_msgSend(self, "NS_initWithCoder:", aCoder);
}
}), new objj_method(sel_getUid("classForKeyedArchiver"), function(self, _cmd)
{ with(self)
{
    return objj_msgSend(_CPCibControlConnector, "class");
}
})]);
}
{var the_class = objj_allocateClassPair(_CPCibOutletConnector, "NSNibOutletConnector"),
meta_class = the_class.isa;objj_registerClassPair(the_class);
objj_addClassForBundle(the_class, objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(the_class, [new objj_method(sel_getUid("initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    return objj_msgSend(self, "NS_initWithCoder:", aCoder);
}
}), new objj_method(sel_getUid("classForKeyedArchiver"), function(self, _cmd)
{ with(self)
{
    return objj_msgSend(_CPCibOutletConnector, "class");
}
})]);
}

p;15;NSPopUpButton.jI;22;AppKit/CPPopUpButton.ji;8;NSMenu.jc;2769;
{
var the_class = objj_getClass("CPPopUpButton")
if(!the_class) objj_exception_throw(new objj_exception(OBJJClassNotFoundException, "*** Could not find definition for class \"CPPopUpButton\""));
var meta_class = the_class.isa;class_addMethods(the_class, [new objj_method(sel_getUid("NS_initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    if (self = objj_msgSendSuper({ receiver:self, super_class:objj_getClass("CPPopUpButton").super_class }, "NS_initWithCoder:", aCoder))
    {
        var cell = objj_msgSend(aCoder, "decodeObjectForKey:", "NSCell");
        _menu = objj_msgSend(cell, "menu");
        _selectedIndex = objj_msgSend(cell, "selectedIndex") || 0;
        _pullsDown = objj_msgSend(cell, "pullsDown");
        _preferredEdge = objj_msgSend(cell, "preferredEdge");
    }
    return self;
}
})]);
}
{var the_class = objj_allocateClassPair(CPPopUpButton, "NSPopUpButton"),
meta_class = the_class.isa;objj_registerClassPair(the_class);
objj_addClassForBundle(the_class, objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(the_class, [new objj_method(sel_getUid("initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    return objj_msgSend(self, "NS_initWithCoder:", aCoder);
}
}), new objj_method(sel_getUid("classForKeyedArchiver"), function(self, _cmd)
{ with(self)
{
    return objj_msgSend(CPPopUpButton, "class");
}
})]);
}
{var the_class = objj_allocateClassPair(NSMenuItemCell, "NSPopUpButtonCell"),
meta_class = the_class.isa;class_addIvars(the_class, [new objj_ivar("pullsDown"), new objj_ivar("selectedIndex"), new objj_ivar("preferredEdge"), new objj_ivar("menu")]);
objj_registerClassPair(the_class);
objj_addClassForBundle(the_class, objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(the_class, [new objj_method(sel_getUid("pullsDown"), function(self, _cmd)
{ with(self)
{
return pullsDown;
}
}),
new objj_method(sel_getUid("selectedIndex"), function(self, _cmd)
{ with(self)
{
return selectedIndex;
}
}),
new objj_method(sel_getUid("preferredEdge"), function(self, _cmd)
{ with(self)
{
return preferredEdge;
}
}),
new objj_method(sel_getUid("menu"), function(self, _cmd)
{ with(self)
{
return menu;
}
}), new objj_method(sel_getUid("initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    self = objj_msgSendSuper({ receiver:self, super_class:objj_getClass("NSMenuItemCell") }, "initWithCoder:", aCoder);
    if (self)
    {
        pullsDown = objj_msgSend(aCoder, "decodeBoolForKey:", "NSPullDown");
        selectedIndex = objj_msgSend(aCoder, "decodeIntForKey:", "NSSelectedIndex");
        preferredEdge = objj_msgSend(aCoder, "decodeIntForKey:", "NSPreferredEdge");
        menu = objj_msgSend(aCoder, "decodeObjectForKey:", "NSMenu");
    }
    return self;
}
})]);
}

p;13;NSResponder.jI;20;AppKit/CPResponder.jc;1158;
{
var the_class = objj_getClass("CPResponder")
if(!the_class) objj_exception_throw(new objj_exception(OBJJClassNotFoundException, "*** Could not find definition for class \"CPResponder\""));
var meta_class = the_class.isa;class_addMethods(the_class, [new objj_method(sel_getUid("NS_initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    self = objj_msgSendSuper({ receiver:self, super_class:objj_getClass("CPResponder").super_class }, "init");
    if (self)
        objj_msgSend(self, "setNextResponder:", objj_msgSend(aCoder, "decodeObjectForKey:", "NSNextResponder"));
    return self;
}
})]);
}
{var the_class = objj_allocateClassPair(CPResponder, "NSResponder"),
meta_class = the_class.isa;objj_registerClassPair(the_class);
objj_addClassForBundle(the_class, objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(the_class, [new objj_method(sel_getUid("initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    return objj_msgSend(self, "NS_initWithCoder:", aCoder);
}
}), new objj_method(sel_getUid("classForKeyedArchiver"), function(self, _cmd)
{ with(self)
{
    return objj_msgSend(CPResponder, "class");
}
})]);
}

p;10;NSSlider.jI;17;AppKit/CPSlider.ji;10;NSSlider.jc;2837;
{
var the_class = objj_getClass("CPSlider")
if(!the_class) objj_exception_throw(new objj_exception(OBJJClassNotFoundException, "*** Could not find definition for class \"CPSlider\""));
var meta_class = the_class.isa;class_addMethods(the_class, [new objj_method(sel_getUid("NS_initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    self = objj_msgSendSuper({ receiver:self, super_class:objj_getClass("CPSlider").super_class }, "NS_initWithCoder:", aCoder);
    if (self)
    {
        var cell = objj_msgSend(aCoder, "decodeObjectForKey:", "NSCell");
        _minValue = objj_msgSend(cell, "minValue");
        _maxValue = objj_msgSend(cell, "maxValue");
        _altIncrementValue = objj_msgSend(cell, "altIncrementValue");
        _isVertical = objj_msgSend(cell, "isVertical");
    }
    return self;
}
})]);
}
{var the_class = objj_allocateClassPair(CPSlider, "NSSlider"),
meta_class = the_class.isa;objj_registerClassPair(the_class);
objj_addClassForBundle(the_class, objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(the_class, [new objj_method(sel_getUid("initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    return objj_msgSend(self, "NS_initWithCoder:", aCoder);
}
}), new objj_method(sel_getUid("classForKeyedArchiver"), function(self, _cmd)
{ with(self)
{
    return objj_msgSend(CPSlider, "class");
}
})]);
}
{var the_class = objj_allocateClassPair(NSCell, "NSSliderCell"),
meta_class = the_class.isa;class_addIvars(the_class, [new objj_ivar("_minValue"), new objj_ivar("_maxValue"), new objj_ivar("_altIncrementValue"), new objj_ivar("_vertical")]);
objj_registerClassPair(the_class);
objj_addClassForBundle(the_class, objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(the_class, [new objj_method(sel_getUid("minValue"), function(self, _cmd)
{ with(self)
{
return _minValue;
}
}),
new objj_method(sel_getUid("maxValue"), function(self, _cmd)
{ with(self)
{
return _maxValue;
}
}),
new objj_method(sel_getUid("altIncrementValue"), function(self, _cmd)
{ with(self)
{
return _altIncrementValue;
}
}),
new objj_method(sel_getUid("isVertical"), function(self, _cmd)
{ with(self)
{
return _vertical;
}
}), new objj_method(sel_getUid("initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    self = objj_msgSendSuper({ receiver:self, super_class:objj_getClass("NSCell") }, "initWithCoder:", aCoder);
    if (self)
    {
        _objectValue = objj_msgSend(aCoder, "decodeDoubleForKey:", "NSValue");
        _minValue = objj_msgSend(aCoder, "decodeDoubleForKey:", "NSMinValue");
        _maxValue = objj_msgSend(aCoder, "decodeDoubleForKey:", "NSMaxValue");
        _altIncrementValue = objj_msgSend(aCoder, "decodeDoubleForKey:", "NSAltIncValue");
        _isVertical = objj_msgSend(aCoder, "decodeBoolForKey:", "NSVertical");
    }
    return self;
}
})]);
}

p;13;NSSplitView.jI;20;AppKit/CPSplitView.jc;1251;
{
var the_class = objj_getClass("CPSplitView")
if(!the_class) objj_exception_throw(new objj_exception(OBJJClassNotFoundException, "*** Could not find definition for class \"CPSplitView\""));
var meta_class = the_class.isa;class_addMethods(the_class, [new objj_method(sel_getUid("NS_initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    if (self = objj_msgSendSuper({ receiver:self, super_class:objj_getClass("CPSplitView").super_class }, "NS_initWithCoder:", aCoder))
    {
        _isVertical = objj_msgSend(aCoder, "decodeBoolForKey:", "NSIsVertical");
        _isPaneSplitter = objj_msgSend(aCoder, "decodeIntForKey:", "NSDividerStyle") == 2 ? YES : NO;
    }
    return self;
}
})]);
}
{var the_class = objj_allocateClassPair(CPSplitView, "NSSplitView"),
meta_class = the_class.isa;objj_registerClassPair(the_class);
objj_addClassForBundle(the_class, objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(the_class, [new objj_method(sel_getUid("initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    return objj_msgSend(self, "NS_initWithCoder:", aCoder);
}
}), new objj_method(sel_getUid("classForKeyedArchiver"), function(self, _cmd)
{ with(self)
{
    return objj_msgSend(CPSplitView, "class");
}
})]);
}

p;13;NSTextField.jI;20;AppKit/CPTextField.ji;11;NSControl.ji;8;NSCell.jc;3984;

{
var the_class = objj_getClass("CPTextField")
if(!the_class) objj_exception_throw(new objj_exception(OBJJClassNotFoundException, "*** Could not find definition for class \"CPTextField\""));
var meta_class = the_class.isa;class_addMethods(the_class, [new objj_method(sel_getUid("NS_initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    self = objj_msgSendSuper({ receiver:self, super_class:objj_getClass("CPTextField").super_class }, "NS_initWithCoder:", aCoder);

    if (self)
    {
        var cell = objj_msgSend(aCoder, "decodeObjectForKey:", "NSCell");

        objj_msgSend(self, "sendActionOn:", CPKeyUpMask|CPKeyDownMask);

  objj_msgSend(self, "setEditable:", objj_msgSend(cell, "isEditable"));
  objj_msgSend(self, "setSelectable:", objj_msgSend(cell, "isSelectable"));

  objj_msgSend(self, "setBordered:", objj_msgSend(cell, "isBordered"));
  objj_msgSend(self, "setBezeled:", objj_msgSend(cell, "isBezeled"));
        objj_msgSend(self, "setBezelStyle:", objj_msgSend(cell, "bezelStyle"));
        objj_msgSend(self, "setDrawsBackground:", objj_msgSend(cell, "drawsBackground"));


        objj_msgSend(self, "setTextFieldBackgroundColor:", objj_msgSend(cell, "backgroundColor"));

  objj_msgSend(self, "setPlaceholderString:", objj_msgSend(cell, "placeholderString"));

        objj_msgSend(self, "setTextColor:", objj_msgSend(cell, "textColor"));

        CPLog.debug(objj_msgSend(self, "stringValue") + " => isBordered=" + objj_msgSend(self, "isBordered") + ", isBezeled=" + objj_msgSend(self, "isBezeled") + ", bezelStyle=" + objj_msgSend(self, "bezelStyle") + "("+objj_msgSend(cell, "stringValue")+", " + objj_msgSend(cell, "placeholderString") + ")");
 }

 return self;
}
})]);
}

{var the_class = objj_allocateClassPair(CPTextField, "NSTextField"),
meta_class = the_class.isa;objj_registerClassPair(the_class);
objj_addClassForBundle(the_class, objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(the_class, [new objj_method(sel_getUid("initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    return objj_msgSend(self, "NS_initWithCoder:", aCoder);
}
}), new objj_method(sel_getUid("classForKeyedArchiver"), function(self, _cmd)
{ with(self)
{
    return objj_msgSend(CPTextField, "class");
}
})]);
}

{var the_class = objj_allocateClassPair(NSCell, "NSTextFieldCell"),
meta_class = the_class.isa;class_addIvars(the_class, [new objj_ivar("_bezelStyle"), new objj_ivar("_drawsBackground"), new objj_ivar("_backgroundColor"), new objj_ivar("_textColor"), new objj_ivar("_placeholderString")]);
objj_registerClassPair(the_class);
objj_addClassForBundle(the_class, objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(the_class, [new objj_method(sel_getUid("bezelStyle"), function(self, _cmd)
{ with(self)
{
return _bezelStyle;
}
}),
new objj_method(sel_getUid("drawsBackground"), function(self, _cmd)
{ with(self)
{
return _drawsBackground;
}
}),
new objj_method(sel_getUid("backgroundColor"), function(self, _cmd)
{ with(self)
{
return _backgroundColor;
}
}),
new objj_method(sel_getUid("textColor"), function(self, _cmd)
{ with(self)
{
return _textColor;
}
}),
new objj_method(sel_getUid("placeholderString"), function(self, _cmd)
{ with(self)
{
return _placeholderString;
}
}), new objj_method(sel_getUid("initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    self = objj_msgSendSuper({ receiver:self, super_class:objj_getClass("NSCell") }, "initWithCoder:", aCoder);

    if (self)
    {
     _bezelStyle = objj_msgSend(aCoder, "decodeObjectForKey:", "NSTextBezelStyle") || CPTextFieldSquareBezel;
        _drawsBackground = objj_msgSend(aCoder, "decodeBoolForKey:", "NSDrawsBackground");
        _backgroundColor = objj_msgSend(aCoder, "decodeObjectForKey:", "NSBackgroundColor");
        _textColor = objj_msgSend(aCoder, "decodeObjectForKey:", "NSTextColor");
        _placeholderString = objj_msgSend(aCoder, "decodeObjectForKey:", "NSPlaceholderString");
    }

    return self;
}
})]);
}

p;11;NSToolbar.jI;18;AppKit/CPToolbar.jc;1916;
{
var the_class = objj_getClass("CPToolbar")
if(!the_class) objj_exception_throw(new objj_exception(OBJJClassNotFoundException, "*** Could not find definition for class \"CPToolbar\""));
var meta_class = the_class.isa;class_addMethods(the_class, [new objj_method(sel_getUid("NS_initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    if (self)
    {
        _identifier = objj_msgSend(aCoder, "decodeObjectForKey:", "NSToolbarIdentifier");
        _displayMode = objj_msgSend(aCoder, "decodeIntForKey:", "NSToolbarDisplayMode");
        _showsBaselineSeparator = objj_msgSend(aCoder, "decodeBoolForKey:", "NSToolbarShowsBaselineSeparator");
        _allowsUserCustomization = objj_msgSend(aCoder, "decodeBoolForKey:", "NSToolbarAllowsUserCustomization");
        _isVisible = objj_msgSend(aCoder, "decodeBoolForKey:", "NSToolbarPrefersToBeShown");
        _identifiedItems = objj_msgSend(aCoder, "decodeObjectForKey:", "NSToolbarIBIdentifiedItems");
        _defaultItems = objj_msgSend(aCoder, "decodeObjectForKey:", "NSToolbarIBDefaultItems");
        _allowedItems = objj_msgSend(aCoder, "decodeObjectForKey:", "NSToolbarIBAllowedItems");
        _selectableItems = objj_msgSend(aCoder, "decodeObjectForKey:", "NSToolbarIBSelectableItems");
        _delegate = objj_msgSend(aCoder, "decodeObjectForKey:", "NSToolbarDelegate");
    }
    return self;
}
})]);
}
{var the_class = objj_allocateClassPair(CPToolbar, "NSToolbar"),
meta_class = the_class.isa;objj_registerClassPair(the_class);
objj_addClassForBundle(the_class, objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(the_class, [new objj_method(sel_getUid("initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    return objj_msgSend(self, "NS_initWithCoder:", aCoder);
}
}), new objj_method(sel_getUid("classForKeyedArchiver"), function(self, _cmd)
{ with(self)
{
    return objj_msgSend(CPToolbar, "class");
}
})]);
}

p;8;NSView.jI;15;AppKit/CPView.jc;3111;
{
var the_class = objj_getClass("CPView")
if(!the_class) objj_exception_throw(new objj_exception(OBJJClassNotFoundException, "*** Could not find definition for class \"CPView\""));
var meta_class = the_class.isa;class_addMethods(the_class, [new objj_method(sel_getUid("NS_initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    _frame = CGRectMakeZero();
    if (objj_msgSend(aCoder, "containsValueForKey:", "NSFrame"))
        _frame = objj_msgSend(aCoder, "decodeRectForKey:", "NSFrame");
    else if (objj_msgSend(aCoder, "containsValueForKey:", "NSFrameSize"))
        _frame.size = objj_msgSend(aCoder, "decodeSizeForKey:", "NSFrameSize");
    self = objj_msgSendSuper({ receiver:self, super_class:objj_getClass("CPView").super_class }, "NS_initWithCoder:", aCoder);
    if (self)
    {
        _tag = -1;
        if(objj_msgSend(aCoder, "containsValueForKey:", "NSTag"))
            _tag = objj_msgSend(aCoder, "decodeIntForKey:", "NSTag");
        _bounds = CGRectMake(0.0, 0.0, CGRectGetWidth(_frame), CGRectGetHeight(_frame));
        _window = objj_msgSend(aCoder, "decodeObjectForKey:", "NSWindow");
        _superview = objj_msgSend(aCoder, "decodeObjectForKey:", "NSSuperview");
        _subviews = objj_msgSend(aCoder, "decodeObjectForKey:", "NSSubviews");
        if (!_subviews)
            _subviews = [];
        var vFlags = objj_msgSend(aCoder, "decodeIntForKey:", "NSvFlags");
        var autoresizingMaskNS = vFlags & 0x3F;
        _autoresizingMask = autoresizingMaskNS & ~(CPViewMaxYMargin | CPViewMinYMargin)
        if (!(autoresizingMaskNS & (CPViewMaxYMargin | CPViewMinYMargin | CPViewHeightSizable)))
        {
            _autoresizingMask |= CPViewMinYMargin;
        }
        else
        {
            if (autoresizingMaskNS & CPViewMaxYMargin)
                _autoresizingMask |= CPViewMinYMargin;
            if (autoresizingMaskNS & CPViewMinYMargin)
                _autoresizingMask |= CPViewMaxYMargin;
        }
        _autoresizesSubviews = vFlags & (1 << 8);
        _hitTests = YES;
        _isHidden = NO;
        _opacity = 1.0;
        if (YES )
        {
            var height = CGRectGetHeight(objj_msgSend(self, "bounds")),
                count = objj_msgSend(_subviews, "count");
            while (count--)
            {
                var subview = _subviews[count],
                    frame = objj_msgSend(subview, "frame");
                objj_msgSend(subview, "setFrameOrigin:", CGPointMake(CGRectGetMinX(frame), height - CGRectGetMaxY(frame)));
            }
        }
    }
    return self;
}
})]);
}
{var the_class = objj_allocateClassPair(CPView, "NSView"),
meta_class = the_class.isa;objj_registerClassPair(the_class);
objj_addClassForBundle(the_class, objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(the_class, [new objj_method(sel_getUid("initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    return objj_msgSend(self, "NS_initWithCoder:", aCoder);
}
}), new objj_method(sel_getUid("classForKeyedArchiver"), function(self, _cmd)
{ with(self)
{
    return objj_msgSend(CPView, "class");
}
})]);
}

p;18;NSWindowTemplate.jI;29;AppKit/_CPCibWindowTemplate.jc;2630;
{
var the_class = objj_getClass("_CPCibWindowTemplate")
if(!the_class) objj_exception_throw(new objj_exception(OBJJClassNotFoundException, "*** Could not find definition for class \"_CPCibWindowTemplate\""));
var meta_class = the_class.isa;class_addMethods(the_class, [new objj_method(sel_getUid("NS_initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    self = objj_msgSendSuper({ receiver:self, super_class:objj_getClass("_CPCibWindowTemplate").super_class }, "init");
    if (self)
    {
        if (objj_msgSend(aCoder, "containsValueForKey:", "NSMinSize"))
            _minSize = objj_msgSend(aCoder, "decodeSizeForKey:", "NSMinSize");
        if (objj_msgSend(aCoder, "containsValueForKey:", "NSMaxSize"))
            _maxSize = objj_msgSend(aCoder, "decodeSizeForKey:", "NSMaxSize");
        _screenRect = objj_msgSend(aCoder, "decodeRectForKey:", "NSScreenRect");
        _viewClass = objj_msgSend(aCoder, "decodeObjectForKey:", "NSViewClass");
        _wtFlags = objj_msgSend(aCoder, "decodeIntForKey:", "NSWTFlags");
        _windowBacking = objj_msgSend(aCoder, "decodeIntForKey:", "NSWindowBacking");
        _windowClass = CP_NSMapClassName(objj_msgSend(aCoder, "decodeObjectForKey:", "NSWindowClass"));
        _windowRect = objj_msgSend(aCoder, "decodeRectForKey:", "NSWindowRect");
        _windowStyleMask = objj_msgSend(aCoder, "decodeIntForKey:", "NSWindowStyleMask");
        _windowTitle = objj_msgSend(aCoder, "decodeObjectForKey:", "NSWindowTitle");
        _windowView = objj_msgSend(aCoder, "decodeObjectForKey:", "NSWindowView");
        _windowRect.origin.y = _screenRect.size.height - _windowRect.origin.y - _windowRect.size.height;
        _windowStyleMask |= CPHUDBackgroundWindowMask;
        if (_windowStyleMask & CPHUDBackgroundWindowMask)
        {
            CPLog.warn("Adjusting window rect.");
            _windowRect.origin.x -= 7.0;
            _windowRect.origin.y -= 30.0;
            _windowRect.size.width += 14.0;
            _windowRect.size.height += 40.0;
        }
   }
   return self;
}
})]);
}
{var the_class = objj_allocateClassPair(_CPCibWindowTemplate, "NSWindowTemplate"),
meta_class = the_class.isa;objj_registerClassPair(the_class);
objj_addClassForBundle(the_class, objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(the_class, [new objj_method(sel_getUid("initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    return objj_msgSend(self, "NS_initWithCoder:", aCoder);
}
}), new objj_method(sel_getUid("classForKeyedArchiver"), function(self, _cmd)
{ with(self)
{
    return objj_msgSend(_CPCibWindowTemplate, "class");
}
})]);
}

p;9;WebView.jI;18;AppKit/CPWebView.jc;1054;
{
var the_class = objj_getClass("CPWebView")
if(!the_class) objj_exception_throw(new objj_exception(OBJJClassNotFoundException, "*** Could not find definition for class \"CPWebView\""));
var meta_class = the_class.isa;class_addMethods(the_class, [new objj_method(sel_getUid("NS_initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    if (self = objj_msgSendSuper({ receiver:self, super_class:objj_getClass("CPWebView").super_class }, "NS_initWithCoder:", aCoder))
    {
    }
    return self;
}
})]);
}
{var the_class = objj_allocateClassPair(CPWebView, "WebView"),
meta_class = the_class.isa;objj_registerClassPair(the_class);
objj_addClassForBundle(the_class, objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(the_class, [new objj_method(sel_getUid("initWithCoder:"), function(self, _cmd, aCoder)
{ with(self)
{
    return objj_msgSend(self, "NS_initWithCoder:", aCoder);
}
}), new objj_method(sel_getUid("classForKeyedArchiver"), function(self, _cmd)
{ with(self)
{
    return objj_msgSend(CPWebView, "class");
}
})]);
}

