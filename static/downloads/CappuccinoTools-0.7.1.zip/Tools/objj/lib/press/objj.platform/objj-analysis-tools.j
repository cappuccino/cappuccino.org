c;5539;
var _1=OBJJ_HOME+"/lib/Frameworks/Objective-J/rhino.platform/Objective-J.js",_2=OBJJ_HOME+"/lib/press/bridge.js",_3="/Users/tlrobinson/280North/git/cappuccino/Tools/press/env.js";
traverseDependencies=function(_4,_5){
if(_4.processedFiles[_5.path]){
return;
}
_4.processedFiles[_5.path]=true;
var _6=false;
if(_4.ignoreAllImports){
CPLog.warn("Ignoring all import fragments. ("+_5.path+")");
_6=true;
}else{
if(_4.ignoreFrameworkImports){
var _7=_5.path.match(new RegExp("([^\\/]+)\\/([^\\/]+)\\.j$"));
if(_7&&_7[1]===_7[2]){
CPLog.warn("Framework import file! Ignoring all import fragments. ("+_5.path+")");
_6=true;
}
}
}
if(!_5.fragments){
if(_5.included){
CPLog.warn(_5.path+" is included but missing fragments");
}else{
CPLog.warn("Preprocessing "+_5.path);
}
_5.fragments=objj_preprocess(_5.contents,_5.bundle,_5);
}
if(!_4.bundleImages){
_4.bundleImages={};
}
if(!_4.bundleImages[_5.bundle.path]){
var _8=new java.io.File(dirname(_5.bundle.path)+"/Resources");
if(_8.exists()){
_4.bundleImages[_5.bundle.path]={};
var _9=find(_8,(new RegExp("\\.png$")));
for(var i=0;i<_9.length;i++){
var _b=pathRelativeTo(_9[i].getCanonicalPath(),_8.getCanonicalPath());
_4.bundleImages[_5.bundle.path][_b]=1;
}
}
}
var _c=_4.bundleImages[_5.bundle.path];
var _d={},_e={};
CPLog.debug("Processing "+_5.path+" fragments ("+_5.fragments.length+")");
for(var i=0;i<_5.fragments.length;i++){
var _f=_5.fragments[i];
if(_f.type&FRAGMENT_CODE){
var _10=new objj_lexer(_f.info,NULL);
var _11;
while(_11=_10.skip_whitespace()){
if(_4.dependencies.hasOwnProperty(_11)){
var _12=_4.dependencies[_11];
for(var j=0;j<_12.length;j++){
if(_12[j]!=_5.path){
if(!_d[_12[j]]){
_d[_12[j]]={};
}
_d[_12[j]][_11]=true;
}
}
}
var _7=_11.match(new RegExp("^['\"](.*)['\"]$"));
if(_7&&_c&&_c[_7[1]]){
_c[_7[1]]=(_c[_7[1]]|2);
}
}
}else{
if(_f.type&FRAGMENT_FILE){
if(_6){
_f.conditionallyIgnore=true;
}else{
var _14=findImportInObjjFiles(_4.scope,_f);
if(_14){
if(_14!=_5.path){
_e[_14]=true;
}else{
CPLog.error("Ignoring self import (why are you importing yourself!?): "+_5.path);
}
}else{
CPLog.error("Couldn't find file for import "+_f.info+"("+_f.type+")");
}
}
}
}
}
for(var _14 in _e){
if(_14!=_5.path){
if(_4.importCallback){
_4.importCallback(_5.path,_14);
}
if(_4.scope.objj_files[_14]){
traverseDependencies(_4,_4.scope.objj_files[_14]);
}else{
CPLog.error("Missing imported file: "+_14);
}
}
}
if(_4.importedFiles){
_4.importedFiles[_5.path]=_e;
}
for(var _15 in _d){
if(_15!=_5.path){
if(_4.referenceCallback){
_4.referenceCallback(_5.path,_15,_d[_15]);
}
if(_4.scope.objj_files.hasOwnProperty(_15)){
traverseDependencies(_4,_4.scope.objj_files[_15]);
}else{
CPLog.error("Missing referenced file: "+_15);
}
}
}
if(_4.referencedFiles){
_4.referencedFiles[_5.path]=_d;
}
};
findImportInObjjFiles=function(_16,_17){
var _18=null;
if(_17.type&FRAGMENT_LOCAL){
var _19=_17.info;
if(_16.objj_files[_19]){
_18=_19;
}
}else{
var _1a=_16.OBJJ_INCLUDE_PATHS.length;
while(_1a--){
var _19=_16.OBJJ_INCLUDE_PATHS[_1a].replace(new RegExp("\\/$"),"")+"/"+_17.info;
if(_16.objj_files[_19]){
_18=_19;
break;
}
}
}
return _18;
};
findGlobalDefines=function(_1b,_1c,_1d,_1e){
addMockBrowserEnvironment(_1c);
var _1f=cloneProperties(_1c,true);
_1f["bundle"]=true;
var _20={};
var _21=_1c.fragment_evaluate_file;
_1c.fragment_evaluate_file=function(_22){
return _21(_22);
};
var _23=_1c.fragment_evaluate_code;
_1c.fragment_evaluate_code=function(_24){
CPLog.debug("Evaling "+_24.file.path+" / "+_24.bundle.path);
var _25=cloneProperties(_1c);
if(_1e){
_1e.push(_24);
}
var _26=_23(_24);
var _27={};
diff(_25,_1c,_1f,_27,_27,null);
_20[_24.file.path]=_27;
return _26;
};
runWithScope(_1b,_1c,function(_28){
objj_import(_28,true,NULL);
},[_1d]);
return _20;
};
coalesceGlobalDefines=function(_29){
var _2a={};
for(var _2b in _29){
var _2c=_29[_2b];
for(var _2d in _2c){
if(!_2a[_2d]){
_2a[_2d]=[];
}
_2a[_2d].push(_2b);
}
}
return _2a;
};
makeObjjScope=function(_2e,_2f){
var _30=_2e.initStandardObjects();
if(_2f){
_30.objj_alert=print;
_30.debug=true;
}
_30.print=function(_31){
Packages.java.lang.System.out.println(String(_31));
};
var _32=readFile(_2);
if(_32){
_2e.evaluateString(_30,_32,"bridge.js",1,null);
}else{
CPLog.warn("Missing bridge.js");
}
var _33=readFile(_1);
if(_33){
_2e.evaluateString(_30,_33,"Objective-J.js",1,null);
}else{
CPLog.warn("Missing Objective-J.js");
}
return _30;
};
runWithScope=function(_34,_35,_36,_37){
_35.__runWithScopeArgs=_37||[];
var _38="("+_36+").apply(this, this.__runWithScopeArgs); serviceTimeouts();";
return _34.evaluateString(_35,_38,"<cmd>",1,null);
};
addMockBrowserEnvironment=function(_39){
_39.Element=function(){
this.style={};
};
_39.document={createElement:function(){
return new _39.Element();
}};
};
cloneProperties=function(_3a,_3b){
var _3c={};
for(var _3d in _3a){
_3c[_3d]=_3b?true:_3a[_3d];
}
return _3c;
};
diff=function(_3e,_3f,_40,_41,_42,_43){
for(var i in _3f){
if(_41&&!_40[i]&&typeof _3e[i]=="undefined"){
_41[i]=true;
}
}
for(var i in _3f){
if(_42&&!_40[i]&&typeof _3e[i]!="undefined"&&typeof _3f[i]!="undefined"&&_3e[i]!==_3f[i]){
_42[i]=true;
}
}
for(var i in _3e){
if(_43&&!_40[i]&&typeof _3f[i]=="undefined"){
_43[i]=true;
}
}
};
allKeys=function(_45){
var _46=[];
for(var i in _45){
_46.push(i);
}
return _46.sort();
};
find=function(src,_49){
var _4a=[];
var _4b=src.listFiles();
for(var i=0;i<_4b.length;i++){
if(_4b[i].isFile()&&_49.test(_4b[i].getAbsolutePath())){
_4a.push(_4b[i]);
}else{
if(_4b[i].isDirectory()){
_4a=Array.prototype.concat.apply(_4a,find(_4b[i],_49));
}
}
}
return _4a;
};
