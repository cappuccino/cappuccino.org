I;16;AppKit/CPColor.jc;1988;
var _1=-1,_2=0,_3=1,_4=2,_5=3,_6=4,_7=5,_8=6;
var _9=objj_getClass("CPColor");
if(!_9){
objj_exception_throw(new objj_exception(OBJJClassNotFoundException,"*** Could not find definition for class \"CPColor\""));
}
var _a=_9.isa;
class_addMethods(_9,[new objj_method(sel_getUid("NS_initWithCoder:"),function(_b,_c,_d){
with(_b){
var _e=objj_msgSend(_d,"decodeIntForKey:","NSColorSpace"),_f;
switch(_e){
case 1:
case 2:
var rgb=objj_msgSend(_d,"decodeBytesForKey:","NSRGB"),_11=bytes_to_string(rgb),_12=objj_msgSend(_11,"componentsSeparatedByString:"," "),_13=[0,0,0,1];
for(var i=0;i<_12.length&&i<4;i++){
_13[i]=objj_msgSend(_12[i],"floatValue");
}
CPLog.warn("rgb="+rgb+" string="+_11+" values="+_13);
_f=objj_msgSend(CPColor,"colorWithCalibratedRed:green:blue:alpha:",_13[0],_13[1],_13[2],_13[3]);
break;
case 3:
case 4:
var _15=objj_msgSend(_d,"decodeBytesForKey:","NSWhite"),_11=bytes_to_string(_15),_12=objj_msgSend(_11,"componentsSeparatedByString:"," "),_13=[0,1];
for(var i=0;i<_12.length&&i<2;i++){
_13[i]=objj_msgSend(_12[i],"floatValue");
}
_f=objj_msgSend(CPColor,"colorWithCalibratedWhite:alpha:",_13[0],_13[1]);
break;
case 6:
var _16=objj_msgSend(_d,"decodeObjectForKey:","NSCatalogName"),_17=objj_msgSend(_d,"decodeObjectForKey:","NSColorName"),_18=objj_msgSend(_d,"decodeObjectForKey:","NSColor");
if(_16==="System"){
var _f=null;
if(!_f){
_f=_18;
}
}else{
_f=null;
if(!_f){
_f=_18;
}
}
break;
default:
CPLog("-[%@ %s] unknown color space %d",isa,_c,_e);
_f=objj_msgSend(CPColor,"blackColor");
break;
}
return _f;
}
})]);
var _9=objj_allocateClassPair(CPColor,"NSColor"),_a=_9.isa;
objj_registerClassPair(_9);
objj_addClassForBundle(_9,objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(_9,[new objj_method(sel_getUid("initWithCoder:"),function(_19,_1a,_1b){
with(_19){
return objj_msgSend(_19,"NS_initWithCoder:",_1b);
}
}),new objj_method(sel_getUid("classForKeyedArchiver"),function(_1c,_1d){
with(_1c){
return objj_msgSend(CPColor,"class");
}
})]);
