I;21;Foundation/CPObject.ji;8;NSFont.jc;3393;
var _1=objj_allocateClassPair(CPObject,"NSCell"),_2=_1.isa;
class_addIvars(_1,[new objj_ivar("_state"),new objj_ivar("_isHighlighted"),new objj_ivar("_isEnabled"),new objj_ivar("_isEditable"),new objj_ivar("_isBordered"),new objj_ivar("_isBezeled"),new objj_ivar("_isSelectable"),new objj_ivar("_isScrollable"),new objj_ivar("_isContinuous"),new objj_ivar("_wraps"),new objj_ivar("_alignment"),new objj_ivar("_controlSize"),new objj_ivar("_objectValue"),new objj_ivar("_font")]);
objj_registerClassPair(_1);
objj_addClassForBundle(_1,objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(_1,[new objj_method(sel_getUid("state"),function(_3,_4){
with(_3){
return _state;
}
}),new objj_method(sel_getUid("isHighlighted"),function(_5,_6){
with(_5){
return _isHighlighted;
}
}),new objj_method(sel_getUid("isEnabled"),function(_7,_8){
with(_7){
return _isEnabled;
}
}),new objj_method(sel_getUid("isEditable"),function(_9,_a){
with(_9){
return _isEditable;
}
}),new objj_method(sel_getUid("isBordered"),function(_b,_c){
with(_b){
return _isBordered;
}
}),new objj_method(sel_getUid("isBezeled"),function(_d,_e){
with(_d){
return _isBezeled;
}
}),new objj_method(sel_getUid("isSelectable"),function(_f,_10){
with(_f){
return _isSelectable;
}
}),new objj_method(sel_getUid("isScrollable"),function(_11,_12){
with(_11){
return _isScrollable;
}
}),new objj_method(sel_getUid("isContinuous"),function(_13,_14){
with(_13){
return _isContinuous;
}
}),new objj_method(sel_getUid("wraps"),function(_15,_16){
with(_15){
return _wraps;
}
}),new objj_method(sel_getUid("alignment"),function(_17,_18){
with(_17){
return _alignment;
}
}),new objj_method(sel_getUid("controlSize"),function(_19,_1a){
with(_19){
return _controlSize;
}
}),new objj_method(sel_getUid("objectValue"),function(_1b,_1c){
with(_1b){
return _objectValue;
}
}),new objj_method(sel_getUid("font"),function(_1d,_1e){
with(_1d){
return _font;
}
}),new objj_method(sel_getUid("initWithCoder:"),function(_1f,_20,_21){
with(_1f){
_1f=objj_msgSendSuper({receiver:_1f,super_class:objj_getClass("CPObject")},"init");
if(_1f){
var _22=objj_msgSend(_21,"decodeIntForKey:","NSCellFlags"),_23=objj_msgSend(_21,"decodeIntForKey:","NSCellFlags2");
_state=(_22&2147483648)?CPOnState:CPOffState;
_isHighlighted=(_22&1073741824)?YES:NO;
_isEnabled=(_22&536870912)?NO:YES;
_isEditable=(_22&268435456)?YES:NO;
_isBordered=(_22&8388608)?YES:NO;
_isBezeled=(_22&4194304)?YES:NO;
_isSelectable=(_22&2097152)?YES:NO;
_isScrollable=(_22&1048576)?YES:NO;
_isContinuous=(_22&524544)?YES:NO;
_wraps=(_22&1048576)?NO:YES;
_alignment=(_23&469762048)>>26;
_controlSize=(_23&917504)>>17;
_objectValue=objj_msgSend(_21,"decodeObjectForKey:","NSContents");
_font=objj_msgSend(_21,"decodeObjectForKey:","NSSupport");
}
return _1f;
}
}),new objj_method(sel_getUid("replacementObjectForCoder:"),function(_24,_25,_26){
with(_24){
return nil;
}
}),new objj_method(sel_getUid("stringValue"),function(_27,_28){
with(_27){
if(objj_msgSend(_objectValue,"isKindOfClass:",objj_msgSend(CPString,"class"))){
return _objectValue;
}
if(objj_msgSend(_objectValue,"respondsToSelector:",sel_getUid("attributedStringValue"))){
return objj_msgSend(_objectValue,"attributedStringValue");
}
return "";
}
})]);
var _1=objj_allocateClassPair(NSCell,"NSActionCell"),_2=_1.isa;
objj_registerClassPair(_1);
objj_addClassForBundle(_1,objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
