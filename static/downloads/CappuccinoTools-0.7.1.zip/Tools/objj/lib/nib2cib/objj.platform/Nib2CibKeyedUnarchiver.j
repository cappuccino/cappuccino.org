I;30;Foundation/CPKeyedUnarchiver.jc;981;
var _1=objj_allocateClassPair(CPKeyedUnarchiver,"Nib2CibKeyedUnarchiver"),_2=_1.isa;
class_addIvars(_1,[new objj_ivar("resourcesFile")]);
objj_registerClassPair(_1);
objj_addClassForBundle(_1,objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(_1,[new objj_method(sel_getUid("initForReadingWithData:resourcesFile:"),function(_3,_4,_5,_6){
with(_3){
_3=objj_msgSendSuper({receiver:_3,super_class:objj_getClass("CPKeyedUnarchiver")},"initForReadingWithData:",_5);
if(_3){
resourcesFile=_6;
}
return _3;
}
}),new objj_method(sel_getUid("resourcesFile"),function(_7,_8){
with(_7){
return resourcesFile;
}
}),new objj_method(sel_getUid("resourceFileForName:"),function(_9,_a,_b){
with(_9){
var _c=[resourcesFile.listFiles()];
do{
var _d=_c.shift(),_e=0,_f=_d.length;
for(;_e<_f;++_e){
var _10=_d[_e].getCanonicalFile(),_11=String(_10.getName());
if(_11===_b){
return _10;
}
if(_10.isDirectory()){
_c.push(_10.listFiles());
}
}
}while(_c.length>0);
return NULL;
}
})]);
