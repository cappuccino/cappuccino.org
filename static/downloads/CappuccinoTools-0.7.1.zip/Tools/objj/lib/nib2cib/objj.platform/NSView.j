I;15;AppKit/CPView.jc;2315;
var _1=objj_getClass("CPView");
if(!_1){
objj_exception_throw(new objj_exception(OBJJClassNotFoundException,"*** Could not find definition for class \"CPView\""));
}
var _2=_1.isa;
class_addMethods(_1,[new objj_method(sel_getUid("NS_initWithCoder:"),function(_3,_4,_5){
with(_3){
_frame=CGRectMakeZero();
if(objj_msgSend(_5,"containsValueForKey:","NSFrame")){
_frame=objj_msgSend(_5,"decodeRectForKey:","NSFrame");
}else{
if(objj_msgSend(_5,"containsValueForKey:","NSFrameSize")){
_frame.size=objj_msgSend(_5,"decodeSizeForKey:","NSFrameSize");
}
}
_3=objj_msgSendSuper({receiver:_3,super_class:objj_getClass("CPView").super_class},"NS_initWithCoder:",_5);
if(_3){
_tag=-1;
if(objj_msgSend(_5,"containsValueForKey:","NSTag")){
_tag=objj_msgSend(_5,"decodeIntForKey:","NSTag");
}
_bounds=CGRectMake(0,0,CGRectGetWidth(_frame),CGRectGetHeight(_frame));
_window=objj_msgSend(_5,"decodeObjectForKey:","NSWindow");
_superview=objj_msgSend(_5,"decodeObjectForKey:","NSSuperview");
_subviews=objj_msgSend(_5,"decodeObjectForKey:","NSSubviews");
if(!_subviews){
_subviews=[];
}
var _6=objj_msgSend(_5,"decodeIntForKey:","NSvFlags");
var _7=_6&63;
_autoresizingMask=_7&~(CPViewMaxYMargin|CPViewMinYMargin);
if(!(_7&(CPViewMaxYMargin|CPViewMinYMargin|CPViewHeightSizable))){
_autoresizingMask|=CPViewMinYMargin;
}else{
if(_7&CPViewMaxYMargin){
_autoresizingMask|=CPViewMinYMargin;
}
if(_7&CPViewMinYMargin){
_autoresizingMask|=CPViewMaxYMargin;
}
}
_autoresizesSubviews=_6&(1<<8);
_hitTests=YES;
_isHidden=NO;
_opacity=1;
if(YES){
var _8=CGRectGetHeight(objj_msgSend(_3,"bounds")),_9=objj_msgSend(_subviews,"count");
while(_9--){
var _a=_subviews[_9],_b=objj_msgSend(_a,"frame");
objj_msgSend(_a,"setFrameOrigin:",CGPointMake(CGRectGetMinX(_b),_8-CGRectGetMaxY(_b)));
}
}
_themeAttributes={};
_themeState=CPThemeStateNormal;
objj_msgSend(_3,"_loadThemeAttributes");
}
return _3;
}
})]);
var _1=objj_allocateClassPair(CPView,"NSView"),_2=_1.isa;
objj_registerClassPair(_1);
objj_addClassForBundle(_1,objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(_1,[new objj_method(sel_getUid("initWithCoder:"),function(_c,_d,_e){
with(_c){
return objj_msgSend(_c,"NS_initWithCoder:",_e);
}
}),new objj_method(sel_getUid("classForKeyedArchiver"),function(_f,_10){
with(_f){
return objj_msgSend(CPView,"class");
}
})]);
