I;29;AppKit/_CPCibCustomResource.jc;1901;
importClass(javax.imageio.ImageIO);
var _1=objj_getClass("_CPCibCustomResource");
if(!_1){
objj_exception_throw(new objj_exception(OBJJClassNotFoundException,"*** Could not find definition for class \"_CPCibCustomResource\""));
}
var _2=_1.isa;
class_addMethods(_1,[new objj_method(sel_getUid("NS_initWithCoder:"),function(_3,_4,_5){
with(_3){
_3=objj_msgSendSuper({receiver:_3,super_class:objj_getClass("_CPCibCustomResource").super_class},"init");
if(_3){
_className=CP_NSMapClassName(objj_msgSend(_5,"decodeObjectForKey:","NSClassName"));
_resourceName=objj_msgSend(_5,"decodeObjectForKey:","NSResourceName");
var _6=CGSizeMakeZero();
if(!objj_msgSend(_5,"resourcesFile")){
CPLog.warn("***WARNING: Resources found in nib, but no resources path specified with -R option.");
_properties=objj_msgSend(CPDictionary,"dictionaryWithObject:forKey:",CGSizeMakeZero(),"size");
}else{
var _7=objj_msgSend(_5,"resourceFileForName:",_resourceName);
if(!_7){
CPLog.warn("***WARNING: Resource named "+_resourceName+" not found in supplied resources path.");
}else{
var _8=ImageIO.createImageInputStream(_7),_9=ImageIO.getImageReaders(_8),_a=null;
if(_9.hasNext()){
_a=_9.next();
}else{
_8.close();
}
_a.setInput(_8,true,true);
_6=CGSizeMake(_a.getWidth(0),_a.getHeight(0));
print(_6.width+" "+_6.height);
_a.dispose();
_8.close();
}
}
_properties=objj_msgSend(CPDictionary,"dictionaryWithObject:forKey:",_6,"size");
}
return _3;
}
})]);
var _1=objj_allocateClassPair(_CPCibCustomResource,"NSCustomResource"),_2=_1.isa;
objj_registerClassPair(_1);
objj_addClassForBundle(_1,objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(_1,[new objj_method(sel_getUid("initWithCoder:"),function(_b,_c,_d){
with(_b){
return objj_msgSend(_b,"NS_initWithCoder:",_d);
}
}),new objj_method(sel_getUid("classForKeyedArchiver"),function(_e,_f){
with(_e){
return objj_msgSend(_CPCibCustomResource,"class");
}
})]);
