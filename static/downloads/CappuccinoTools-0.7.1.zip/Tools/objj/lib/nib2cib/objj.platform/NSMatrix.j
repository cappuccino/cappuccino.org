I;21;Foundation/CPObject.jI;15;AppKit/CPView.ji;8;NSView.jc;1604;
var _1=objj_allocateClassPair(CPObject,"NSMatrix"),_2=_1.isa;
objj_registerClassPair(_1);
objj_addClassForBundle(_1,objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(_1,[new objj_method(sel_getUid("initWithCoder:"),function(_3,_4,_5){
with(_3){
var _6=objj_msgSend(objj_msgSend(CPView,"alloc"),"NS_initWithCoder:",_5);
objj_msgSend(_6,"setBackgroundColor:",objj_msgSend(_5,"decodeObjectForKey:","NSBackgroundColor"));
var _7=objj_msgSend(_5,"decodeIntForKey:","NSNumRows"),_8=objj_msgSend(_5,"decodeIntForKey:","NSNumCols"),_9=objj_msgSend(_5,"decodeSizeForKey:","NSCellSize"),_a=objj_msgSend(_5,"decodeSizeForKey:","NSIntercellSpacing"),_b=objj_msgSend(_5,"decodeObjectForKey:","NSCellBackgroundColor"),_c=objj_msgSend(_5,"decodeIntForKey:","NSMatrixFlags"),_d=objj_msgSend(_5,"decodeObjectForKey:","NSCells"),_e=objj_msgSend(_5,"decodeObjectForKey:","NSSelectedCell");
if((_c&1073741824)){
var _f=objj_msgSend(CPRadioGroup,"new");
frame=CGRectMake(0,0,_9.width,_9.height);
rowIndex=0;
for(;rowIndex<_7;++rowIndex){
var _10=0;
frame.origin.x=0;
for(;_10<_8;++_10){
var _11=_d[rowIndex*_8+_10],_12=objj_msgSend(objj_msgSend(CPRadio,"alloc"),"initWithFrame:radioGroup:",frame,_f);
objj_msgSend(_12,"setAutoresizingMask:",CPViewWidthSizable|CPViewHeightSizable);
objj_msgSend(_12,"setTitle:",objj_msgSend(_11,"title"));
objj_msgSend(_12,"setBackgroundColor:",_b);
objj_msgSend(_12,"setObjectValue:",objj_msgSend(_11,"objectValue"));
objj_msgSend(_6,"addSubview:",_12);
frame.origin.x=CGRectGetMaxX(frame)+_a.width;
}
frame.origin.y=CGRectGetMaxY(frame)+_a.height;
}
}
return _6;
}
})]);
