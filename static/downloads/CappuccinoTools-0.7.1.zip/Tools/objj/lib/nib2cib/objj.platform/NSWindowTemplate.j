I;29;AppKit/_CPCibWindowTemplate.jc;2394;
var _1=0,_2=1,_3=2,_4=4,_5=8,_6=16,_7=256,_8=8192;
var _9=objj_getClass("_CPCibWindowTemplate");
if(!_9){
objj_exception_throw(new objj_exception(OBJJClassNotFoundException,"*** Could not find definition for class \"_CPCibWindowTemplate\""));
}
var _a=_9.isa;
class_addMethods(_9,[new objj_method(sel_getUid("NS_initWithCoder:"),function(_b,_c,_d){
with(_b){
_b=objj_msgSendSuper({receiver:_b,super_class:objj_getClass("_CPCibWindowTemplate").super_class},"init");
if(_b){
if(objj_msgSend(_d,"containsValueForKey:","NSMinSize")){
_minSize=objj_msgSend(_d,"decodeSizeForKey:","NSMinSize");
}
if(objj_msgSend(_d,"containsValueForKey:","NSMaxSize")){
_maxSize=objj_msgSend(_d,"decodeSizeForKey:","NSMaxSize");
}
_screenRect=objj_msgSend(_d,"decodeRectForKey:","NSScreenRect");
_viewClass=objj_msgSend(_d,"decodeObjectForKey:","NSViewClass");
_wtFlags=objj_msgSend(_d,"decodeIntForKey:","NSWTFlags");
_windowBacking=objj_msgSend(_d,"decodeIntForKey:","NSWindowBacking");
_windowClass=CP_NSMapClassName(objj_msgSend(_d,"decodeObjectForKey:","NSWindowClass"));
_windowRect=objj_msgSend(_d,"decodeRectForKey:","NSWindowRect");
_windowStyleMask=objj_msgSend(_d,"decodeIntForKey:","NSWindowStyleMask");
_windowTitle=objj_msgSend(_d,"decodeObjectForKey:","NSWindowTitle");
_windowView=objj_msgSend(_d,"decodeObjectForKey:","NSWindowView");
_windowRect.origin.y=_screenRect.size.height-_windowRect.origin.y-_windowRect.size.height;
if(_windowStyleMask===_1){
_windowStyleMask=CPBorderlessWindowMask;
}else{
_windowStyleMask=(_windowStyleMask&_2?CPTitledWindowMask:0)|(_windowStyleMask&_3?CPClosableWindowMask:0)|(_windowStyleMask&_4?CPMiniaturizableWindowMask:0)|(_windowStyleMask&_5?CPResizableWindowMask:0)|(_windowStyleMask&_7?_7:0)|(_windowStyleMask&_8?CPHUDBackgroundWindowMask:0);
}
_windowIsFullBridge=objj_msgSend(_d,"decodeObjectForKey:","NSFrameAutosaveName")==="CPBorderlessBridgeWindowMask";
}
return _b;
}
})]);
var _9=objj_allocateClassPair(_CPCibWindowTemplate,"NSWindowTemplate"),_a=_9.isa;
objj_registerClassPair(_9);
objj_addClassForBundle(_9,objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(_9,[new objj_method(sel_getUid("initWithCoder:"),function(_e,_f,_10){
with(_e){
return objj_msgSend(_e,"NS_initWithCoder:",_10);
}
}),new objj_method(sel_getUid("classForKeyedArchiver"),function(_11,_12){
with(_11){
return objj_msgSend(_CPCibWindowTemplate,"class");
}
})]);
