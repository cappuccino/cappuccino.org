I;27;AppKit/CPSegmentedControl.jc;4247;
var _1=objj_getClass("CPSegmentedControl");
if(!_1){
objj_exception_throw(new objj_exception(OBJJClassNotFoundException,"*** Could not find definition for class \"CPSegmentedControl\""));
}
var _2=_1.isa;
class_addMethods(_1,[new objj_method(sel_getUid("NS_initWithCoder:"),function(_3,_4,_5){
with(_3){
_segments=[];
_themeStates=[];
if(_3=objj_msgSendSuper({receiver:_3,super_class:objj_getClass("CPSegmentedControl").super_class},"NS_initWithCoder:",_5)){
var _6=objj_msgSend(_3,"frame"),_7=_6.size.width;
_6.size.width=0;
_6.origin.x=MAX(_6.origin.x-4,0);
objj_msgSend(_3,"setFrame:",_6);
var _8=objj_msgSend(_5,"decodeObjectForKey:","NSCell");
_segments=objj_msgSend(_8,"segments");
_selectedSegment=objj_msgSend(_8,"selectedSegment");
_segmentStyle=objj_msgSend(_8,"segmentStyle");
_trackingMode=objj_msgSend(_8,"trackingMode");
objj_msgSend(_3,"setValue:forThemeAttribute:",CPCenterTextAlignment,"alignment");
for(var i=0;i<_segments.length;i++){
_themeStates[i]=_segments[i].selected?CPThemeStateSelected:CPThemeStateNormal;
objj_msgSend(_3,"tileWithChangedSegment:",i);
}
_6.size.width=_7;
objj_msgSend(_3,"setFrame:",_6);
}
return _3;
}
})]);
var _1=objj_allocateClassPair(CPSegmentedControl,"NSSegmentedControl"),_2=_1.isa;
objj_registerClassPair(_1);
objj_addClassForBundle(_1,objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(_1,[new objj_method(sel_getUid("initWithCoder:"),function(_a,_b,_c){
with(_a){
return objj_msgSend(_a,"NS_initWithCoder:",_c);
}
}),new objj_method(sel_getUid("classForKeyedArchiver"),function(_d,_e){
with(_d){
return objj_msgSend(CPSegmentedControl,"class");
}
})]);
var _1=objj_allocateClassPair(NSActionCell,"NSSegmentedCell"),_2=_1.isa;
class_addIvars(_1,[new objj_ivar("_segments"),new objj_ivar("_selectedSegment"),new objj_ivar("_segmentStyle"),new objj_ivar("_trackingMode")]);
objj_registerClassPair(_1);
objj_addClassForBundle(_1,objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(_1,[new objj_method(sel_getUid("segments"),function(_f,_10){
with(_f){
return _segments;
}
}),new objj_method(sel_getUid("selectedSegment"),function(_11,_12){
with(_11){
return _selectedSegment;
}
}),new objj_method(sel_getUid("segmentStyle"),function(_13,_14){
with(_13){
return _segmentStyle;
}
}),new objj_method(sel_getUid("trackingMode"),function(_15,_16){
with(_15){
return _trackingMode;
}
}),new objj_method(sel_getUid("initWithCoder:"),function(_17,_18,_19){
with(_17){
if(_17=objj_msgSendSuper({receiver:_17,super_class:objj_getClass("NSActionCell")},"initWithCoder:",_19)){
_segments=objj_msgSend(_19,"decodeObjectForKey:","NSSegmentImages");
_selectedSegment=objj_msgSend(_19,"decodeIntForKey:","NSSelectedSegment");
_segmentStyle=objj_msgSend(_19,"decodeIntForKey:","NSSegmentStyle");
_trackingMode=objj_msgSend(_19,"decodeIntForKey:","NSTrackingMode");
}
return _17;
}
})]);
var _1=objj_getClass("_CPSegmentItem");
if(!_1){
objj_exception_throw(new objj_exception(OBJJClassNotFoundException,"*** Could not find definition for class \"_CPSegmentItem\""));
}
var _2=_1.isa;
class_addMethods(_1,[new objj_method(sel_getUid("NS_initWithCoder:"),function(_1a,_1b,_1c){
with(_1a){
if(_1a=objj_msgSendSuper({receiver:_1a,super_class:objj_getClass("_CPSegmentItem").super_class},"init")){
image=objj_msgSend(_1c,"decodeObjectForKey:","NSSegmentItemImage");
label=objj_msgSend(_1c,"decodeObjectForKey:","NSSegmentItemLabel");
menu=objj_msgSend(_1c,"decodeObjectForKey:","NSSegmentItemMenu");
selected=objj_msgSend(_1c,"decodeBoolForKey:","NSSegmentItemSelected");
enabled=!objj_msgSend(_1c,"decodeBoolForKey:","NSSegmentItemDisabled");
tag=objj_msgSend(_1c,"decodeIntForKey:","NSSegmentItemTag");
width=objj_msgSend(_1c,"decodeIntForKey:","NSSegmentItemWidth");
frame=CGRectMakeZero();
}
return _1a;
}
})]);
var _1=objj_allocateClassPair(_CPSegmentItem,"NSSegmentItem"),_2=_1.isa;
objj_registerClassPair(_1);
objj_addClassForBundle(_1,objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(_1,[new objj_method(sel_getUid("initWithCoder:"),function(_1d,_1e,_1f){
with(_1d){
return objj_msgSend(_1d,"NS_initWithCoder:",_1f);
}
}),new objj_method(sel_getUid("classForKeyedArchiver"),function(_20,_21){
with(_20){
return objj_msgSend(_CPSegmentItem,"class");
}
})]);
