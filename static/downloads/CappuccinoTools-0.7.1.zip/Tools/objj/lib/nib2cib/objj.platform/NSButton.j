I;17;AppKit/CPButton.jI;19;AppKit/CPCheckBox.jI;16;AppKit/CPRadio.ji;8;NSCell.ji;11;NSControl.jc;5011;
var _1={};
_1[CPRoundedBezelStyle]=18;
_1[CPTexturedRoundedBezelStyle]=20;
_1[CPHUDBezelStyle]=20;
var _2=objj_getClass("CPButton");
if(!_2){
objj_exception_throw(new objj_exception(OBJJClassNotFoundException,"*** Could not find definition for class \"CPButton\""));
}
var _3=_2.isa;
class_addMethods(_2,[new objj_method(sel_getUid("NS_initWithCoder:"),function(_4,_5,_6){
with(_4){
_4=objj_msgSendSuper({receiver:_4,super_class:objj_getClass("CPButton").super_class},"NS_initWithCoder:",_6);
if(_4){
var _7=objj_msgSend(_6,"decodeObjectForKey:","NSCell");
_controlSize=CPRegularControlSize;
_title=objj_msgSend(_7,"title");
if(!objj_msgSend(_4,"NS_isCheckBox")&&!objj_msgSend(_4,"NS_isRadio")){
objj_msgSend(_4,"setBordered:",objj_msgSend(_7,"isBordered"));
_bezelStyle=objj_msgSend(_7,"bezelStyle");
switch(_bezelStyle){
case CPRoundedBezelStyle:
case CPTexturedRoundedBezelStyle:
case CPHUDBezelStyle:
break;
case CPRoundRectBezelStyle:
_bezelStyle=CPRoundedBezelStyle;
break;
case CPSmallSquareBezelStyle:
case CPThickSquareBezelStyle:
case CPThickerSquareBezelStyle:
case CPRegularSquareBezelStyle:
case CPTexturedSquareBezelStyle:
case CPShadowlessSquareBezelStyle:
_bezelStyle=CPTexturedRoundedBezelStyle;
break;
case CPRecessedBezelStyle:
_bezelStyle=CPHUDBezelStyle;
break;
case CPRoundedDisclosureBezelStyle:
case CPHelpButtonBezelStyle:
case CPCircularBezelStyle:
case CPDisclosureBezelStyle:
CPLog.warn("Unsupported bezel style: "+_bezelStyle);
_bezelStyle=CPHUDBezelStyle;
break;
default:
CPLog.error("Unknown bezel style: "+_bezelStyle);
_bezelStyle=CPHUDBezelStyle;
}
_frame.size.height=24;
_bounds.size.height=24;
}else{
objj_msgSend(_4,"setBordered:",YES);
}
}
return _4;
}
}),new objj_method(sel_getUid("NS_isCheckBox"),function(_8,_9){
with(_8){
return NO;
}
}),new objj_method(sel_getUid("NS_isRadio"),function(_a,_b){
with(_a){
return NO;
}
})]);
var _2=objj_allocateClassPair(CPButton,"NSButton"),_3=_2.isa;
class_addIvars(_2,[new objj_ivar("_isCheckBox"),new objj_ivar("_isRadio")]);
objj_registerClassPair(_2);
objj_addClassForBundle(_2,objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(_2,[new objj_method(sel_getUid("NS_isCheckBox"),function(_c,_d){
with(_c){
return _isCheckBox;
}
}),new objj_method(sel_getUid("NS_isRadio"),function(_e,_f){
with(_e){
return _isRadio;
}
}),new objj_method(sel_getUid("initWithCoder:"),function(_10,_11,_12){
with(_10){
var _13=objj_msgSend(_12,"decodeObjectForKey:","NSCell"),_14=objj_msgSend(_13,"alternateImage");
if(objj_msgSend(_14,"isKindOfClass:",objj_msgSend(NSButtonImageSource,"class"))){
if(objj_msgSend(_14,"imageName")==="NSSwitch"){
_isCheckBox=YES;
}else{
if(objj_msgSend(_14,"imageName")==="NSRadioButton"){
_isRadio=YES;
_10._radioGroup=objj_msgSend(CPRadioGroup,"new");
}
}
}
return objj_msgSend(_10,"NS_initWithCoder:",_12);
}
}),new objj_method(sel_getUid("classForKeyedArchiver"),function(_15,_16){
with(_15){
if(objj_msgSend(_15,"NS_isCheckBox")){
return objj_msgSend(CPCheckBox,"class");
}
if(objj_msgSend(_15,"NS_isRadio")){
return objj_msgSend(CPRadio,"class");
}
return objj_msgSend(CPButton,"class");
}
})]);
var _2=objj_allocateClassPair(NSActionCell,"NSButtonCell"),_3=_2.isa;
class_addIvars(_2,[new objj_ivar("_isBordered"),new objj_ivar("_bezelStyle"),new objj_ivar("_title"),new objj_ivar("_alternateImage")]);
objj_registerClassPair(_2);
objj_addClassForBundle(_2,objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(_2,[new objj_method(sel_getUid("isBordered"),function(_17,_18){
with(_17){
return _isBordered;
}
}),new objj_method(sel_getUid("bezelStyle"),function(_19,_1a){
with(_19){
return _bezelStyle;
}
}),new objj_method(sel_getUid("title"),function(_1b,_1c){
with(_1b){
return _title;
}
}),new objj_method(sel_getUid("alternateImage"),function(_1d,_1e){
with(_1d){
return _alternateImage;
}
}),new objj_method(sel_getUid("initWithCoder:"),function(_1f,_20,_21){
with(_1f){
_1f=objj_msgSendSuper({receiver:_1f,super_class:objj_getClass("NSActionCell")},"initWithCoder:",_21);
if(_1f){
var _22=objj_msgSend(_21,"decodeIntForKey:","NSButtonFlags"),_23=objj_msgSend(_21,"decodeIntForKey:","NSButtonFlags2");
_isBordered=(_22&8388608)?YES:NO;
_bezelStyle=(_23&7)|((_23&32)>>2);
_title=objj_msgSend(_21,"decodeObjectForKey:","NSContents");
_objectValue=objj_msgSend(_1f,"state");
_alternateImage=objj_msgSend(_21,"decodeObjectForKey:","NSAlternateImage");
}
return _1f;
}
})]);
var _2=objj_allocateClassPair(CPObject,"NSButtonImageSource"),_3=_2.isa;
class_addIvars(_2,[new objj_ivar("_imageName")]);
objj_registerClassPair(_2);
objj_addClassForBundle(_2,objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(_2,[new objj_method(sel_getUid("imageName"),function(_24,_25){
with(_24){
return _imageName;
}
}),new objj_method(sel_getUid("initWithCoder:"),function(_26,_27,_28){
with(_26){
_26=objj_msgSendSuper({receiver:_26,super_class:objj_getClass("CPObject")},"init");
if(_26){
_imageName=objj_msgSend(_28,"decodeObjectForKey:","NSImageName");
}
return _26;
}
})]);
