I;23;Foundation/Foundation.ji;14;OJTestResult.jc;4583;
AssertionFailedError="AssertionFailedError";
var _1=objj_allocateClassPair(CPObject,"OJTestCase"),_2=_1.isa;
class_addIvars(_1,[new objj_ivar("_selector")]);
objj_registerClassPair(_1);
objj_addClassForBundle(_1,objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(_1,[new objj_method(sel_getUid("createResult"),function(_3,_4){
with(_3){
return objj_msgSend(objj_msgSend(OJTestResult,"alloc"),"init");
}
}),new objj_method(sel_getUid("run"),function(_5,_6){
with(_5){
var _7=objj_msgSend(_5,"createResult");
objj_msgSend(_5,"run:",_7);
return _7;
}
}),new objj_method(sel_getUid("run:"),function(_8,_9,_a){
with(_8){
objj_msgSend(_a,"run:",_8);
}
}),new objj_method(sel_getUid("runBare"),function(_b,_c){
with(_b){
objj_msgSend(_b,"setUp");
try{
objj_msgSend(_b,"runTest");
}
finally{
objj_msgSend(_b,"tearDown");
}
}
}),new objj_method(sel_getUid("runTest"),function(_d,_e){
with(_d){
objj_msgSend(_d,"assertNotNull:",_selector);
objj_msgSend(_d,"performSelector:",_selector);
}
}),new objj_method(sel_getUid("setUp"),function(_f,_10){
with(_f){
}
}),new objj_method(sel_getUid("tearDown"),function(_11,_12){
with(_11){
}
}),new objj_method(sel_getUid("selector"),function(_13,_14){
with(_13){
return _selector;
}
}),new objj_method(sel_getUid("setSelector:"),function(_15,_16,_17){
with(_15){
_selector=_17;
}
}),new objj_method(sel_getUid("countTestCases"),function(_18,_19){
with(_18){
return 1;
}
}),new objj_method(sel_getUid("assertTrue:"),function(_1a,_1b,_1c){
with(_1a){
objj_msgSend(_1a,"assertTrue:message:",_1c,"expected YES but got NO");
}
}),new objj_method(sel_getUid("assertTrue:message:"),function(_1d,_1e,_1f,_20){
with(_1d){
if(!_1f){
objj_msgSend(_1d,"fail:",_20);
}
}
}),new objj_method(sel_getUid("assertFalse:"),function(_21,_22,_23){
with(_21){
objj_msgSend(_21,"assertFalse:message:",_23,"expected NO but gut YES");
}
}),new objj_method(sel_getUid("assertFalse:message:"),function(_24,_25,_26,_27){
with(_24){
objj_msgSend(_24,"assertTrue:message:",(!_26),_27);
}
}),new objj_method(sel_getUid("assert:equals:"),function(_28,_29,_2a,_2b){
with(_28){
objj_msgSend(_28,"assert:equals:message:",_2a,_2b,nil);
}
}),new objj_method(sel_getUid("assert:equals:message:"),function(_2c,_2d,_2e,_2f,_30){
with(_2c){
if(_2e!==_2f&&!objj_msgSend(_2e,"isEqual:",_2f)){
objj_msgSend(_2c,"failNotEqual:actual:message:",_2e,_2f,_30);
}
}
}),new objj_method(sel_getUid("assert:same:"),function(_31,_32,_33,_34){
with(_31){
objj_msgSend(_31,"assert:same:message:",_33,_34,nil);
}
}),new objj_method(sel_getUid("assert:same:message:"),function(_35,_36,_37,_38,_39){
with(_35){
if(_37!==_38){
objj_msgSend(_35,"failSame:actual:message:",_37,_38,_39);
}
}
}),new objj_method(sel_getUid("assert:notSame:"),function(_3a,_3b,_3c,_3d){
with(_3a){
objj_msgSend(_3a,"assert:notSame:message:",_3c,_3d,nil);
}
}),new objj_method(sel_getUid("assert:notSame:message:"),function(_3e,_3f,_40,_41,_42){
with(_3e){
if(_40===_41){
objj_msgSend(_3e,"failNotSame:actual:message:",_40,_41,_42);
}
}
}),new objj_method(sel_getUid("assertNull:"),function(_43,_44,_45){
with(_43){
objj_msgSend(_43,"assertNull:message:",_45,"expected null but got "+_45);
}
}),new objj_method(sel_getUid("assertNull:message:"),function(_46,_47,_48,_49){
with(_46){
objj_msgSend(_46,"assertTrue:message:",(_48===null),_49);
}
}),new objj_method(sel_getUid("assertNotNull:"),function(_4a,_4b,_4c){
with(_4a){
objj_msgSend(_4a,"assertNotNull:message:",_4c,"expected an object but got null");
}
}),new objj_method(sel_getUid("assertNotNull:message:"),function(_4d,_4e,_4f,_50){
with(_4d){
objj_msgSend(_4d,"assertTrue:message:",(_4f!==null),_50);
}
}),new objj_method(sel_getUid("fail"),function(_51,_52){
with(_51){
objj_msgSend(_51,"fail:",nil);
}
}),new objj_method(sel_getUid("fail:"),function(_53,_54,_55){
with(_53){
objj_msgSend(CPException,"raise:reason:",AssertionFailedError,(_55||"Unknown"));
}
}),new objj_method(sel_getUid("failSame:actual:message:"),function(_56,_57,_58,_59,_5a){
with(_56){
objj_msgSend(_56,"fail:",((_5a?_5a+" ":"")+"expected not same"));
}
}),new objj_method(sel_getUid("failNotSame:actual:message:"),function(_5b,_5c,_5d,_5e,_5f){
with(_5b){
objj_msgSend(_5b,"fail:",((_5f?_5f+" ":"")+"expected same:<"+_5d+"> was not:<"+_5e+">"));
}
}),new objj_method(sel_getUid("failNotEqual:actual:message:"),function(_60,_61,_62,_63,_64){
with(_60){
objj_msgSend(_60,"fail:",((_64?_64+" ":"")+"expected:<"+_62+"> but was:<"+_63+">"));
}
}),new objj_method(sel_getUid("description"),function(_65,_66){
with(_65){
return "["+objj_msgSend(_65,"className")+" "+_selector+"]";
}
})]);
