I;23;Foundation/Foundation.jc;2989;
var _1=objj_allocateClassPair(CPObject,"OJTestSuite"),_2=_1.isa;
class_addIvars(_1,[new objj_ivar("_tests"),new objj_ivar("_name")]);
objj_registerClassPair(_1);
objj_addClassForBundle(_1,objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(_1,[new objj_method(sel_getUid("init"),function(_3,_4){
with(_3){
if(_3=objj_msgSendSuper({receiver:_3,super_class:objj_getClass("CPObject")},"init")){
_tests=[];
}
return _3;
}
}),new objj_method(sel_getUid("initWithName:"),function(_5,_6,_7){
with(_5){
if(_5=objj_msgSend(_5,"init")){
objj_msgSend(_5,"setName:",_7);
}
return _5;
}
}),new objj_method(sel_getUid("initWithClass:"),function(_8,_9,_a){
with(_8){
if(_8=objj_msgSend(_8,"init")){
var _b=_a,_c=[];
while(_b){
var _d=class_copyMethodList(_b);
for(var i=0;i<_d.length;i++){
objj_msgSend(_8,"addTestMethod:names:class:",_d[i].name,_c,_a);
}
_b=_b.super_class;
}
if(objj_msgSend(_tests,"count")==0){
CPLog.warn("No tests");
}
}
return _8;
}
}),new objj_method(sel_getUid("initWithClass:name:"),function(_f,_10,_11,_12){
with(_f){
objj_msgSend(_f,"initWithClass:",_11);
objj_msgSend(_f,"setName:",_12);
}
}),new objj_method(sel_getUid("addTest:"),function(_13,_14,_15){
with(_13){
objj_msgSend(_tests,"addObject:",_15);
}
}),new objj_method(sel_getUid("addTestSuite:"),function(_16,_17,_18){
with(_16){
objj_msgSend(_16,"addTest:",objj_msgSend(objj_msgSend(OJTestSuite,"alloc"),"initWithClass:",_18));
}
}),new objj_method(sel_getUid("addTestMethod:names:class:"),function(_19,_1a,_1b,_1c,_1d){
with(_19){
if(objj_msgSend(_1c,"containsObject:",_1b)||!objj_msgSend(_19,"isTestMethod:",_1b)){
return;
}
objj_msgSend(_1c,"addObject:",_1b);
objj_msgSend(_19,"addTest:",objj_msgSend(_19,"createTestWithSelector:class:",_1b,_1d));
}
}),new objj_method(sel_getUid("createTestWithSelector:class:"),function(_1e,_1f,_20,_21){
with(_1e){
var _22=objj_msgSend(_1e,"getTestConstructor:",_21);
var _23;
if(_20.indexOf(":")<0){
_23=objj_msgSend(objj_msgSend(_21,"alloc"),"performSelector:",_22);
if(objj_msgSend(_23,"isKindOfClass:",objj_msgSend(OJTestCase,"class"))){
objj_msgSend(_23,"setSelector:",_20);
}
}else{
_23=objj_msgSend(_21,"performSelector:withObject:",_22,_20);
}
return _23;
}
}),new objj_method(sel_getUid("isTestMethod:"),function(_24,_25,_26){
with(_24){
return _26.substring(0,4)=="test"&&_26.indexOf(":")==-1;
}
}),new objj_method(sel_getUid("getTestConstructor:"),function(_27,_28,_29){
with(_27){
return "init";
}
}),new objj_method(sel_getUid("run:"),function(_2a,_2b,_2c){
with(_2a){
for(var i=0;i<_tests.length;i++){
if(objj_msgSend(_2c,"shouldStop")){
break;
}
objj_msgSend(_tests[i],"run:",_2c);
}
}
}),new objj_method(sel_getUid("name"),function(_2e,_2f){
with(_2e){
return _name;
}
}),new objj_method(sel_getUid("setName:"),function(_30,_31,_32){
with(_30){
_name=_32;
}
}),new objj_method(sel_getUid("countTestCases"),function(_33,_34){
with(_33){
var _35=0;
for(var i=0;i<_tests.length;i++){
objj_msgSend(_tests[i],"countTestCases");
}
return _35;
}
})]);
