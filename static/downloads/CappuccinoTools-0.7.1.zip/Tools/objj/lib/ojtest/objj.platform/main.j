I;23;Foundation/Foundation.ji;12;OJTestCase.ji;13;OJTestSuite.ji;14;OJTestResult.ji;20;OJTestListenerText.jc;2414;
CPLogRegister(CPLogPrint,"warn");
var _1=objj_allocateClassPair(CPObject,"OJTestRunnerText"),_2=_1.isa;
class_addIvars(_1,[new objj_ivar("_listener")]);
objj_registerClassPair(_1);
objj_addClassForBundle(_1,objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(_1,[new objj_method(sel_getUid("init"),function(_3,_4){
with(_3){
if(_3=objj_msgSendSuper({receiver:_3,super_class:objj_getClass("CPObject")},"init")){
_listener=objj_msgSend(objj_msgSend(OJTestListenerText,"alloc"),"init");
}
return _3;
}
}),new objj_method(sel_getUid("getTest:"),function(_5,_6,_7){
with(_5){
var _8=objj_lookUpClass(_7);
if(_8){
var _9=objj_msgSend(objj_msgSend(OJTestSuite,"alloc"),"initWithClass:",_8);
return _9;
}
CPLog.warn("unable to get tests");
return nil;
}
}),new objj_method(sel_getUid("startWithArguments:"),function(_a,_b,_c){
with(_a){
var _d=_c.shift();
if(!_d){
objj_msgSend(_a,"report");
return;
}
var _e=_d.match(/([^\/]+)\.j$/);
print(_e[1]);
var _f=_e[1];
objj_import(_d,YES,function(){
var _10=objj_msgSend(_a,"getTest:",_f);
objj_msgSend(_a,"run:",_10);
objj_msgSend(_a,"startWithArguments:",_c);
});
}
}),new objj_method(sel_getUid("run:wait:"),function(_11,_12,_13,_14){
with(_11){
var _15=objj_msgSend(objj_msgSend(OJTestResult,"alloc"),"init");
objj_msgSend(_15,"addListener:",_listener);
objj_msgSend(_13,"run:",_15);
return _15;
}
}),new objj_method(sel_getUid("run:"),function(_16,_17,_18){
with(_16){
return objj_msgSend(_16,"run:wait:",_18,NO);
}
}),new objj_method(sel_getUid("report"),function(_19,_1a){
with(_19){
var _1b=objj_msgSend(objj_msgSend(_listener,"errors"),"count")+objj_msgSend(objj_msgSend(_listener,"failures"),"count");
if(!_1b){
return CPLog.info("End of all tests.");
}
CPLog.fatal("Test suite failed with "+objj_msgSend(objj_msgSend(_listener,"errors"),"count")+" errors and "+objj_msgSend(objj_msgSend(_listener,"failures"),"count")+" failures.");
}
})]);
class_addMethods(_2,[new objj_method(sel_getUid("runTest:"),function(_1c,_1d,_1e){
with(_1c){
var _1f=objj_msgSend(objj_msgSend(OJTestRunnerText,"alloc"),"init");
objj_msgSend(_1f,"run:",_1e);
}
}),new objj_method(sel_getUid("runClass:"),function(_20,_21,_22){
with(_20){
objj_msgSend(_20,"runTest:",objj_msgSend(objj_msgSend(OJTestSuite,"alloc"),"initWithClass:",_22));
}
})]);
print(args);
runner=objj_msgSend(objj_msgSend(OJTestRunnerText,"alloc"),"init");
objj_msgSend(runner,"startWithArguments:",args);
