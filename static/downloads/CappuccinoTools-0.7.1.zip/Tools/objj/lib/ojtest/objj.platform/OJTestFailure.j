I;23;Foundation/Foundation.jc;1254;
var _1=objj_allocateClassPair(CPObject,"OJTestFailure"),_2=_1.isa;
class_addIvars(_1,[new objj_ivar("_failedTest"),new objj_ivar("_thrownException")]);
objj_registerClassPair(_1);
objj_addClassForBundle(_1,objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(_1,[new objj_method(sel_getUid("initWithTest:exception:"),function(_3,_4,_5,_6){
with(_3){
if(_3=objj_msgSendSuper({receiver:_3,super_class:objj_getClass("CPObject")},"init")){
_failedTest=_5;
_thrownException=_6;
}
return _3;
}
}),new objj_method(sel_getUid("failedTest"),function(_7,_8){
with(_7){
return _failedTest;
}
}),new objj_method(sel_getUid("thrownException"),function(_9,_a){
with(_9){
return _thrownException;
}
}),new objj_method(sel_getUid("description"),function(_b,_c){
with(_b){
return objj_msgSend(_failedTest,"description")+": "+objj_msgSend(_thrownException,"description");
}
}),new objj_method(sel_getUid("trace"),function(_d,_e){
with(_d){
return "Trace not implemented";
}
}),new objj_method(sel_getUid("exceptionMessage"),function(_f,_10){
with(_f){
return objj_msgSend(_thrownException,"description");
}
}),new objj_method(sel_getUid("isFailure"),function(_11,_12){
with(_11){
return objj_msgSend(_thrownException,"name")==AssertionFailedError;
}
})]);
