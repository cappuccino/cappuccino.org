I;23;Foundation/Foundation.ji;15;OJTestFailure.jc;3088;
var _1=objj_allocateClassPair(CPObject,"OJTestResult"),_2=_1.isa;
class_addIvars(_1,[new objj_ivar("_failures"),new objj_ivar("_errors"),new objj_ivar("_listeners"),new objj_ivar("_runTests"),new objj_ivar("_stop")]);
objj_registerClassPair(_1);
objj_addClassForBundle(_1,objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(_1,[new objj_method(sel_getUid("init"),function(_3,_4){
with(_3){
if(_3=objj_msgSendSuper({receiver:_3,super_class:objj_getClass("CPObject")},"init")){
_failures=[];
_errors=[];
_listeners=[];
_runTests=0;
_stop=NO;
}
return _3;
}
}),new objj_method(sel_getUid("addError:forTest:"),function(_5,_6,_7,_8){
with(_5){
objj_msgSend(_failures,"addObject:",objj_msgSend(objj_msgSend(OJTestFailure,"alloc"),"initWithTest:exception:",_8,_7));
for(var i=0;i<_listeners.length;i++){
objj_msgSend(_listeners[i],"addError:forTest:",_7,_8);
}
}
}),new objj_method(sel_getUid("addFailure:forTest:"),function(_a,_b,_c,_d){
with(_a){
objj_msgSend(_errors,"addObject:",objj_msgSend(objj_msgSend(OJTestFailure,"alloc"),"initWithTest:exception:",_d,_c));
for(var i=0;i<_listeners.length;i++){
objj_msgSend(_listeners[i],"addFailure:forTest:",_c,_d);
}
}
}),new objj_method(sel_getUid("startTest:"),function(_f,_10,_11){
with(_f){
_runTests+=objj_msgSend(_11,"countTestCases");
for(var i=0;i<_listeners.length;i++){
objj_msgSend(_listeners[i],"startTest:",_11);
}
}
}),new objj_method(sel_getUid("endTest:"),function(_13,_14,_15){
with(_13){
for(var i=0;i<_listeners.length;i++){
objj_msgSend(_listeners[i],"endTest:",_15);
}
}
}),new objj_method(sel_getUid("run:"),function(_17,_18,_19){
with(_17){
objj_msgSend(_17,"startTest:",_19);
try{
objj_msgSend(_19,"runBare");
}
catch(e){
if(!e.isa){
e=objj_msgSend(CPException,"exceptionWithName:reason:userInfo:",e.name,e.message,nil);
}
if(objj_msgSend(e,"name")==AssertionFailedError){
objj_msgSend(_17,"addFailure:forTest:",e,_19);
}else{
objj_msgSend(_17,"addError:forTest:",e,_19);
}
}
objj_msgSend(_17,"endTest:",_19);
}
}),new objj_method(sel_getUid("addListener:"),function(_1a,_1b,_1c){
with(_1a){
objj_msgSend(_listeners,"addObject:",_1c);
}
}),new objj_method(sel_getUid("removeListener:"),function(_1d,_1e,_1f){
with(_1d){
objj_msgSend(_listeners,"removeObject:",_1f);
}
}),new objj_method(sel_getUid("runCount"),function(_20,_21){
with(_20){
return _runTests;
}
}),new objj_method(sel_getUid("shouldStop"),function(_22,_23){
with(_22){
return _stop;
}
}),new objj_method(sel_getUid("stop"),function(_24,_25){
with(_24){
_stop=YES;
}
}),new objj_method(sel_getUid("failureCount"),function(_26,_27){
with(_26){
return objj_msgSend(_failures,"count");
}
}),new objj_method(sel_getUid("failures"),function(_28,_29){
with(_28){
return _failures;
}
}),new objj_method(sel_getUid("errorCount"),function(_2a,_2b){
with(_2a){
return objj_msgSend(_errors,"count");
}
}),new objj_method(sel_getUid("errors"),function(_2c,_2d){
with(_2c){
return _errors;
}
}),new objj_method(sel_getUid("wasSuccessful"),function(_2e,_2f){
with(_2e){
return objj_msgSend(_2e,"failureCount")==0&&objj_msgSend(_2e,"errorCount")==0;
}
})]);
