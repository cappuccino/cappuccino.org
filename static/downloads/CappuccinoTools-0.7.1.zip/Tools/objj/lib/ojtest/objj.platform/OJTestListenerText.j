I;23;Foundation/Foundation.jc;1289;
var _1=objj_allocateClassPair(CPObject,"OJTestListenerText"),_2=_1.isa;
class_addIvars(_1,[new objj_ivar("_errors"),new objj_ivar("_failures")]);
objj_registerClassPair(_1);
objj_addClassForBundle(_1,objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(_1,[new objj_method(sel_getUid("init"),function(_3,_4){
with(_3){
_3=objj_msgSendSuper({receiver:_3,super_class:objj_getClass("CPObject")},"init");
_errors=[];
_failures=[];
return _3;
}
}),new objj_method(sel_getUid("addError:forTest:"),function(_5,_6,_7,_8){
with(_5){
_errors.push(_7);
CPLog.error("addError  test="+objj_msgSend(_8,"description")+" error="+_7);
}
}),new objj_method(sel_getUid("errors"),function(_9,_a){
with(_9){
return _errors;
}
}),new objj_method(sel_getUid("addFailure:forTest:"),function(_b,_c,_d,_e){
with(_b){
_failures.push(_d);
CPLog.warn("addFailure test="+objj_msgSend(_e,"description")+" failure="+_d);
}
}),new objj_method(sel_getUid("failures"),function(_f,_10){
with(_f){
return _failures;
}
}),new objj_method(sel_getUid("startTest:"),function(_11,_12,_13){
with(_11){
CPLog.info("startTest  test="+objj_msgSend(_13,"description"));
}
}),new objj_method(sel_getUid("endTest:"),function(_14,_15,_16){
with(_14){
CPLog.info("endTest    test="+objj_msgSend(_16,"description"));
}
})]);
