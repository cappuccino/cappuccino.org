i;15;Configuration.jc;3681;
var _1=require("file");
gen=function(){
var _2=0,_3=arguments.length,_4=false,_5=false,_6=false,_7=false,_8="Application",_9="";
for(;_2<_3;++_2){
var _a=arguments[_2];
switch(_a){
case "-l":
_4=true;
break;
case "-t":
case "--template":
_8=arguments[++_2];
break;
case "-f":
case "--frameworks":
_5=true;
break;
case "--noconfig":
_6=true;
break;
case "--force":
_7=true;
break;
default:
_9=_a;
}
}
if(!_5&&_9.length===0){
_9="Untitled";
}
var _b=new java.io.File(OBJJ_HOME+"/lib/capp/Resources/Templates/"+_8),_c=new java.io.File(_9),_d=_6?objj_msgSend(Configuration,"defaultConfiguration"):objj_msgSend(Configuration,"userConfiguration");
if(_5){
createFrameworksInFile(_c,_4,_7);
}else{
if(!_c.exists()){
exec(["cp","-vR",_b.getCanonicalPath(),_c.getCanonicalPath()],true);
var _e=getFiles(_c),_2=0,_3=_e.length,_f=String(_c.getName()),_10=objj_msgSend(_d,"valueForKey:","organization.identifier")||"";
objj_msgSend(_d,"setTemporaryValue:forKey:",_f,"project.name");
objj_msgSend(_d,"setTemporaryValue:forKey:",_10+"."+toIdentifier(_f),"project.identifier");
objj_msgSend(_d,"setTemporaryValue:forKey:",toIdentifier(_f),"project.nameasidentifier");
for(;_2<_3;++_2){
var _11=_e[_2],_12=_1.read(_11,{charset:"UTF-8"}),key=nil,_14=objj_msgSend(_d,"keyEnumerator");
if(_11.indexOf(".gif")!==-1){
continue;
}
while(key=objj_msgSend(_14,"nextObject")){
_12=_12.replace(new RegExp("__"+key+"__","g"),objj_msgSend(_d,"valueForKey:",key));
}
_1.write(_11,_12,{charset:"UTF-8"});
}
createFrameworksInFile(_c,_4);
}else{
print("Directory already exists");
}
}
};
createFrameworksInFile=function(_15,_16,_17){
var _18=new java.io.File(_15.getCanonicalPath()+"/Frameworks"),_19=new java.io.File(_15.getCanonicalPath()+"/Frameworks/Debug");
if(_18.exists()){
if(_17){
print("Updating existing Frameworks directory.");
exec(["rm","-rf",_18.getCanonicalPath()],true);
}else{
print("Frameworks directory already exists. Use --force to overwrite.");
return;
}
}else{
print("Creating Frameworks directory.");
}
if(!_16){
var _1a=new java.io.File(OBJJ_HOME+"/lib/Frameworks");
exec(["cp","-R",_1a.getCanonicalPath(),_18.getCanonicalPath()],true);
return;
}
var _1b=system.env["CAPP_BUILD"]||system.env["STEAM_BUILD"];
if(!_1b){
throw "CAPP_BUILD or STEAM_BUILD must be defined";
}
new java.io.File(_18).mkdir();
exec(["ln","-s",new java.io.File(_1b+"/Release/Objective-J").getCanonicalPath(),new java.io.File(_15.getCanonicalPath()+"/Frameworks/Objective-J").getCanonicalPath()],true);
exec(["ln","-s",new java.io.File(_1b+"/Release/Foundation").getCanonicalPath(),new java.io.File(_15.getCanonicalPath()+"/Frameworks/Foundation").getCanonicalPath()],true);
exec(["ln","-s",new java.io.File(_1b+"/Release/AppKit").getCanonicalPath(),new java.io.File(_15.getCanonicalPath()+"/Frameworks/AppKit").getCanonicalPath()],true);
new java.io.File(_19).mkdir();
exec(["ln","-s",new java.io.File(_1b+"/Debug/Objective-J").getCanonicalPath(),new java.io.File(_15.getCanonicalPath()+"/Frameworks/Debug/Objective-J").getCanonicalPath()],true);
exec(["ln","-s",new java.io.File(_1b+"/Debug/Foundation").getCanonicalPath(),new java.io.File(_15.getCanonicalPath()+"/Frameworks/Debug/Foundation").getCanonicalPath()],true);
exec(["ln","-s",new java.io.File(_1b+"/Debug/AppKit").getCanonicalPath(),new java.io.File(_15.getCanonicalPath()+"/Frameworks/Debug/AppKit").getCanonicalPath()],true);
};
toIdentifier=function(_1c){
var _1d="",_1e=0,_1f=_1c.length,_20=NO,_21=new RegExp("^[a-zA-Z_$]"),_22=new RegExp("^[a-zA-Z_$0-9]");
for(;_1e<_1f;++_1e){
var _23=_1c.charAt(_1e);
if((_1e===0)&&_21.test(_23)||_22.test(_23)){
if(_20){
_1d+=_23.toUpperCase();
}else{
_1d+=_23;
}
_20=NO;
}else{
_20=YES;
}
}
return _1d;
};
