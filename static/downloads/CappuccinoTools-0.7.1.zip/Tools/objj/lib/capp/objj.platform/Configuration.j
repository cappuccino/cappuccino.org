I;25;Foundation/CPDictionary.jI;21;Foundation/CPString.jI;21;Foundation/CPObject.jc;4456;
var _1=nil,_2=nil,_3=nil;
var _4=objj_allocateClassPair(CPObject,"Configuration"),_5=_4.isa;
class_addIvars(_4,[new objj_ivar("path"),new objj_ivar("dictionary")]);
objj_registerClassPair(_4);
objj_addClassForBundle(_4,objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(_4,[new objj_method(sel_getUid("initWithPath:"),function(_6,_7,_8){
with(_6){
_6=objj_msgSendSuper({receiver:_6,super_class:objj_getClass("CPObject")},"init");
if(_6){
path=_8;
dictionary=objj_msgSend(CPDictionary,"dictionary"),temporaryDictionary=objj_msgSend(CPDictionary,"dictionary");
if(_8){
var _9=new java.io.File(objj_msgSend(_6,"path"));
if(_9.canRead()){
try{
var _a=objj_msgSend(CPData,"dataWithString:",readFile(_9.getCanonicalPath())),_b=objj_msgSend(_a,"string");
if(_b&&_b.length){
dictionary=CPPropertyListCreateFromData(_a);
}
}
catch(e){
}
}
}
}
return _6;
}
}),new objj_method(sel_getUid("path"),function(_c,_d){
with(_c){
return path;
}
}),new objj_method(sel_getUid("storedKeyEnumerator"),function(_e,_f){
with(_e){
return objj_msgSend(dictionary,"keyEnumerator");
}
}),new objj_method(sel_getUid("keyEnumerator"),function(_10,_11){
with(_10){
var set=objj_msgSend(CPSet,"setWithArray:",objj_msgSend(dictionary,"allKeys"));
objj_msgSend(set,"addObjectsFromArray:",objj_msgSend(temporaryDictionary,"allKeys"));
objj_msgSend(set,"addObjectsFromArray:",objj_msgSend(_1,"allKeys"));
return objj_msgSend(set,"objectEnumerator");
}
}),new objj_method(sel_getUid("valueForKey:"),function(_13,_14,_15){
with(_13){
var _16=objj_msgSend(dictionary,"objectForKey:",_15);
if(!_16){
_16=objj_msgSend(temporaryDictionary,"objectForKey:",_15);
}
if(!_16){
_16=objj_msgSend(_1,"objectForKey:",_15);
}
return _16;
}
}),new objj_method(sel_getUid("setValue:forKey:"),function(_17,_18,_19,_1a){
with(_17){
objj_msgSend(dictionary,"setObject:forKey:",_19,_1a);
}
}),new objj_method(sel_getUid("setTemporaryValue:forKey:"),function(_1b,_1c,_1d,_1e){
with(_1b){
objj_msgSend(temporaryDictionary,"setObject:forKey:",_1d,_1e);
}
}),new objj_method(sel_getUid("save"),function(_1f,_20){
with(_1f){
if(!objj_msgSend(_1f,"path")){
return;
}
var _21=new BufferedWriter(new FileWriter(new java.io.File(objj_msgSend(_1f,"path"))));
_21.write(objj_msgSend(CPPropertyListCreate280NorthData(dictionary,kCFPropertyListXMLFormat_v1_0),"string"));
_21.close();
}
})]);
class_addMethods(_5,[new objj_method(sel_getUid("initialize"),function(_22,_23){
with(_22){
if(_22!==objj_msgSend(Configuration,"class")){
return;
}
_1=objj_msgSend(CPDictionary,"dictionary");
objj_msgSend(_1,"setObject:forKey:","You","user.name");
objj_msgSend(_1,"setObject:forKey:","you@yourcompany.com","user.email");
objj_msgSend(_1,"setObject:forKey:","Your Company","organization.name");
objj_msgSend(_1,"setObject:forKey:","feedback @nospam@ yourcompany.com","organization.email");
objj_msgSend(_1,"setObject:forKey:","http://yourcompany.com","organization.url");
objj_msgSend(_1,"setObject:forKey:","com.yourcompany","organization.identifier");
var _24=new Date(),_25=["Janurary","February","March","April","May","June","July","August","September","October","November","December"];
objj_msgSend(_1,"setObject:forKey:",_24.getFullYear(),"project.year");
objj_msgSend(_1,"setObject:forKey:",_25[_24.getMonth()]+" "+_24.getDate()+", "+_24.getFullYear(),"project.date");
}
}),new objj_method(sel_getUid("defaultConfiguration"),function(_26,_27){
with(_26){
if(!_2){
_2=objj_msgSend(objj_msgSend(_26,"alloc"),"initWithPath:",nil);
}
return _2;
}
}),new objj_method(sel_getUid("userConfiguration"),function(_28,_29){
with(_28){
if(!_3){
_3=objj_msgSend(objj_msgSend(_28,"alloc"),"initWithPath:",String(new java.io.File(java.lang.System.getProperty("user.home")+"/.cappconfig").getCanonicalPath()));
}
return _3;
}
})]);
config=function(){
var _2a=0,_2b=arguments.length,key=NULL,_2d=NULL,_2e=NO,_2f=NO;
for(;_2a<_2b;++_2a){
var _30=arguments[_2a];
switch(_30){
case "--get":
_2e=YES;
break;
case "-l":
case "--list":
_2f=YES;
break;
default:
if(key===NULL){
key=_30;
}else{
_2d=_30;
}
}
}
var _31=objj_msgSend(Configuration,"userConfiguration");
if(_2f){
var key=nil,_32=objj_msgSend(_31,"storedKeyEnumerator");
while(key=objj_msgSend(_32,"nextObject")){
print(key+"="+objj_msgSend(_31,"valueForKey:",key));
}
}else{
if(_2e){
var _2d=objj_msgSend(_31,"valueForKey:",key);
if(_2d){
print(_2d);
}
}else{
if(key!==NULL&&_2d!==NULL){
objj_msgSend(_31,"setValue:forKey:",_2d,key);
objj_msgSend(_31,"save");
}
}
}
};
