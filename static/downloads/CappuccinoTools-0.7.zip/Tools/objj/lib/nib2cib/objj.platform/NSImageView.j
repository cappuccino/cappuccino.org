I;20;AppKit/CPImageView.jc;3185;
var _1=objj_getClass("CPImageView");
if(!_1){
objj_exception_throw(new objj_exception(OBJJClassNotFoundException,"*** Could not find definition for class \"CPImageView\""));
}
var _2=_1.isa;
class_addMethods(_1,[new objj_method(sel_getUid("NS_initWithCoder:"),function(_3,_4,_5){
with(_3){
_3=objj_msgSendSuper({receiver:_3,super_class:objj_getClass("CPImageView").super_class},"NS_initWithCoder:",_5);
if(_3){
var _6=objj_msgSend(_5,"decodeObjectForKey:","NSCell");
_imageScaling=objj_msgSend(_6,"imageScaling");
}
return _3;
}
})]);
var _1=objj_allocateClassPair(CPImageView,"NSImageView"),_2=_1.isa;
objj_registerClassPair(_1);
objj_addClassForBundle(_1,objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(_1,[new objj_method(sel_getUid("initWithCoder:"),function(_7,_8,_9){
with(_7){
return objj_msgSendSuper({receiver:_7,super_class:objj_getClass("CPImageView")},"NS_initWithCoder:",_9);
}
}),new objj_method(sel_getUid("classForKeyedArchiver"),function(_a,_b){
with(_a){
return objj_msgSend(CPImageView,"class");
}
})]);
NSImageAlignCenter=0;
NSImageAlignTop=1;
NSImageAlignTopLeft=2;
NSImageAlignTopRight=3;
NSImageAlignLeft=4;
NSImageAlignBottom=5;
NSImageAlignBottomLeft=6;
NSImageAlignBottomRight=7;
NSImageAlignRight=8;
NSImageScaleProportionallyDown=0;
NSImageScaleAxesIndependently=1;
NSImageScaleNone=2;
NSImageScaleProportionallyUpOrDown=3;
NSImageFrameNone=0;
NSImageFramePhoto=1;
NSImageFrameGrayBezel=2;
NSImageFrameGroove=3;
NSImageFrameButton=4;
var _c={};
_c[NSImageScaleProportionallyDown]=CPScaleProportionally;
_c[NSImageScaleAxesIndependently]=CPScaleToFit;
_c[NSImageScaleNone]=CPScaleNone;
_c[NSImageScaleProportionallyUpOrDown]=CPScaleProportionally;
var _1=objj_allocateClassPair(NSCell,"NSImageCell"),_2=_1.isa;
class_addIvars(_1,[new objj_ivar("_animates"),new objj_ivar("_imageAlignment"),new objj_ivar("_imageScaling"),new objj_ivar("_frameStyle")]);
objj_registerClassPair(_1);
objj_addClassForBundle(_1,objj_getBundleWithPath(OBJJ_CURRENT_BUNDLE.path));
class_addMethods(_1,[new objj_method(sel_getUid("_animates"),function(_d,_e){
with(_d){
return _animates;
}
}),new objj_method(sel_getUid("_setAnimates:"),function(_f,_10,_11){
with(_f){
_animates=_11;
}
}),new objj_method(sel_getUid("_imageAlignment"),function(_12,_13){
with(_12){
return _imageAlignment;
}
}),new objj_method(sel_getUid("_setImageAlignment:"),function(_14,_15,_16){
with(_14){
_imageAlignment=_16;
}
}),new objj_method(sel_getUid("imageScaling"),function(_17,_18){
with(_17){
return _imageScaling;
}
}),new objj_method(sel_getUid("_frameStyle"),function(_19,_1a){
with(_19){
return _frameStyle;
}
}),new objj_method(sel_getUid("_setFrameStyle:"),function(_1b,_1c,_1d){
with(_1b){
_frameStyle=_1d;
}
}),new objj_method(sel_getUid("initWithCoder:"),function(_1e,_1f,_20){
with(_1e){
_1e=objj_msgSendSuper({receiver:_1e,super_class:objj_getClass("NSCell")},"initWithCoder:",_20);
if(_1e){
_animates=objj_msgSend(_20,"decodeBoolForKey:","NSAnimates");
_imageAlignment=objj_msgSend(_20,"decodeIntForKey:","NSAlign");
_imageScaling=_c[objj_msgSend(_20,"decodeIntForKey:","NSScale")];
_frameStyle=objj_msgSend(_20,"decodeIntForKey:","NSStyle");
}
return _1e;
}
})]);
