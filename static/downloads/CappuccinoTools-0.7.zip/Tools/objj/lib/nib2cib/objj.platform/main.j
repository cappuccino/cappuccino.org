I;23;Foundation/Foundation.jI;14;AppKit/CPCib.ji;14;NSFoundation.ji;10;NSAppKit.ji;24;Nib2CibKeyedUnarchiver.jc;3653;
var _1=require("file");
importPackage(java.io);
CPLogRegister(CPLogPrint);
exec=function(_2){
var p=Packages.java.lang.Runtime.getRuntime().exec(_2);
var _4=p.waitFor();
var _5=new Packages.java.io.BufferedReader(new Packages.java.io.InputStreamReader(p.getInputStream()));
while(s=_5.readLine()){
print(s);
}
var _5=new Packages.java.io.BufferedReader(new Packages.java.io.InputStreamReader(p.getErrorStream()));
while(s=_5.readLine()){
print(s);
}
return _4;
};
printUsage=function(){
java.lang.System.out.println("usage: nib2cib INPUT_FILE [OUTPUT_FILE] [-F /path/to/required/framework]");
java.lang.System.exit(1);
};
cibExtension=function(_6){
var _7=_6.length-1;
while(_6.charAt(_7)==="/"){
_7--;
}
_6=_6.substr(0,_7+1);
var _8=_6.lastIndexOf(".");
if(_8==-1){
return _6+".cib";
}
var _9=_6.lastIndexOf("/");
if(_9>_8){
return _6+".cib";
}
return _6.substr(0,_8)+".cib";
};
convert=function(_a,_b,_c){
var _d=nil;
if(_c){
_d=new java.io.File(_c).getCanonicalFile();
if(!_d.canRead()){
print("Could not find Resources at "+_d);
return;
}
}
if(!(new Packages.java.io.File(_a)).canRead()){
print("Could not read file at "+_a);
return;
}
var _e=java.io.File.createTempFile("temp",".nib"),_f=_e.getAbsolutePath();
_e.deleteOnExit();
if(exec(["/usr/bin/ibtool",_a,"--compile",_f])){
print("Could not compile file at "+_a);
return;
}
var _10=java.io.File.createTempFile("temp",".plist"),_11=String(_10.getAbsolutePath());
_10.deleteOnExit();
if(exec(["/usr/bin/plutil","-convert","xml1",_f,"-o",_11])){
print("Could not convert to xml plist for file at "+_a);
return;
}
var _12=objj_msgSend(CPData,"dataWithString:",_1.read(String(_11),{charset:"UTF8"}));
objj_msgSend(_12,"setString:",objj_msgSend(_12,"string").replace(/\<key\>\s*CF\$UID\s*\<\/key\>/g,"<key>CP$UID</key>"));
var _13=objj_msgSend(objj_msgSend(Nib2CibKeyedUnarchiver,"alloc"),"initForReadingWithData:resourcesFile:",_12,_d),_14=objj_msgSend(_13,"decodeObjectForKey:","IB.objectdata"),_12=objj_msgSend(CPData,"data"),_15=objj_msgSend(objj_msgSend(CPKeyedArchiver,"alloc"),"initForWritingWithMutableData:",_12);
objj_msgSend(_15,"encodeObject:forKey:",_14,"CPCibObjectDataKey");
objj_msgSend(_15,"finishEncoding");
_1.write(_b,objj_msgSend(_12,"string"),{charset:"UTF8"});
};
loadFrameworks=function(_16,_17){
if(_16.length===0){
return _17();
}
var _18=_16.shift(),_19=new java.io.File(_18+"/Info.plist");
if(!_19.exists()){
java.lang.System.out.println("'"+_18+"' is not a framework or could not be found.");
java.lang.System.exit(1);
}
var _1a=CPPropertyListCreateFromData(objj_msgSend(CPData,"dataWithString:",_1.read(_18+"/Info.plist",{charset:"UTF8"})));
if(objj_msgSend(_1a,"objectForKey:","CPBundlePackageType")!=="FMWK"){
java.lang.System.out.println("'"+_18+"' is not a framework.");
java.lang.System.exit(1);
}
var _1b=objj_msgSend(_1a,"objectForKey:","CPBundleReplacedFiles"),_1c=_1b.length;
if(_1c){
var _1d=new objj_context();
_1d.didCompleteCallback=function(){
loadFrameworks(_16,_17);
};
while(_1c--){
_1d.pushFragment(fragment_create_file(_18+"/"+_1b[_1c],new objj_bundle(""),YES,NULL));
}
_1d.evaluate();
}else{
loadFrameworks(_16,_17);
}
};
main=function(){
var _1e=arguments.length;
if(_1e<1){
printUsage();
}
var _1f=0,_20=nil,_21=nil,_22=nil,_23=[];
for(;_1f<_1e;++_1f){
switch(arguments[_1f]){
case "-help":
case "--help":
printUsage();
case "-F":
_23.push(arguments[++_1f]);
break;
case "-R":
_22=arguments[++_1f];
break;
default:
if(_20&&_20.length>0){
_21=arguments[_1f];
}else{
_20=arguments[_1f];
}
}
}
if(!_21||_21.length<1){
_21=cibExtension(_20);
}
if(_23.length){
loadFrameworks(_23,function(){
convert(_20,_21,_22);
});
}else{
convert(_20,_21,_22);
}
};
