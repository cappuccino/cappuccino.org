c;151;
importClass(java.io.FileWriter);
importClass(java.io.FileOutputStream);
importClass(java.io.BufferedWriter);
importClass(java.io.OutputStreamWriter);
I;23;Foundation/Foundation.ji;15;Configuration.ji;10;Generate.jc;2754;
main=function(){
if(system.args.length<1){
return printUsage();
}
var _1=0,_2=system.args.length;
for(;_1<_2;++_1){
var _3=system.args[_1];
switch(_3){
case "version":
case "--version":
return print("capp version 0.7.0");
case "-h":
case "--help":
return printUsage();
case "config":
return config.apply(this,system.args.slice(_1+1));
case "gen":
return gen.apply(this,system.args.slice(_1+1));
default:
print("unknown command "+_3);
}
}
};
printUsage=function(){
print("capp [--version] COMMAND [ARGS]");
print("    --version         Print version");
print("    -h, --help        Print usage");
print("");
print(ANSITextApplyProperties("    gen",ANSI_BOLD)+" PATH          Generate new project at PATH from a predefined template");
print("    -l                Symlink the Frameworks folder to your $CAPP_BUILD or $STEAM_BUILD directory");
print("    -t, --template    Specify the template name to use (listed in capp/Resources/Templates)");
print("    -f, --frameworks  Create only frameworks, not a full application");
print("    --force           Overwrite Frameworks directory if it already exists");
print("");
print(ANSITextApplyProperties("    config ",ANSI_BOLD));
print("    name value        Set a value for a given key");
print("    -l, --list        List all variables set in config file.");
print("    --get name        Get the value for a given key");
};
writeContentsToFile=function(_4,_5){
var _6=new BufferedWriter(new FileWriter(_5));
_6.write(_4);
_6.close();
};
exec=function(_7,_8){
var _9="",_a="",_b=Packages.java.lang.Runtime.getRuntime().exec(_7),_c=new Packages.java.io.BufferedReader(new Packages.java.io.InputStreamReader(_b.getInputStream()));
while(_9=_c.readLine()){
if(_8){
Packages.java.lang.System.out.println(_9);
}
_a+=_9+"\n";
}
_c=new Packages.java.io.BufferedReader(new Packages.java.io.InputStreamReader(_b.getErrorStream()));
while(_9=_c.readLine()){
Packages.java.lang.System.out.println(_9);
}
try{
if(_b.waitFor()!=0){
Packages.java.lang.System.err.println("exit value = "+_b.exitValue());
}
}
catch(anException){
Packages.java.lang.System.err.println(anException);
}
return _a;
};
getFiles=function(_d,_e,_f){
var _10=[],_11=_d.listFiles(),_12=typeof _e!=="string";
if(_11){
var _13=0,_14=_11.length;
for(;_13<_14;++_13){
var _15=_11[_13].getCanonicalFile(),_16=String(_15.getName()),_17=!_e;
if(_f&&fileArrayContainsFile(_f,_15)){
continue;
}
if(!_17){
if(_12){
var _18=_e.length;
while(_18--&&!_17){
var _19=_e[_18];
if(_16.substring(_16.length-_19.length-1)===("."+_19)){
_17=true;
}
}
}else{
if(_16.substring(_16.length-_e.length-1)===("."+_e)){
_17=true;
}
}
}
if(_15.isDirectory()){
_10=_10.concat(getFiles(_15,_e,_f));
}else{
if(_17){
_10.push(String(_15.getCanonicalPath()));
}
}
}
}
return _10;
};
