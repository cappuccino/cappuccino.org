When /^I click on the editable text-field and enter the value (.*)$/ do |value|
  # Here we tell to the app to simulate a click on the CPTextField with the property cucappIdentifier set to myTextField
  app.gui.simulate_left_click       "//CPTextField[cucappIdentifier='myTextField']"

  # Here we tell to the app to simulate keyboard events with the value got in parameters
  app.gui.simulate_keyboard_events  value

  # Here we tell to the app to simulate a newline character keyboard event
  app.gui.simulate_keyboard_event   $CPNewlineCharacter
end