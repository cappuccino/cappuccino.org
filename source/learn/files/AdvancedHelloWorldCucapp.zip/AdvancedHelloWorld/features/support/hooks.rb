Before do
  app.reset()
end

After do
  app.quit()
end