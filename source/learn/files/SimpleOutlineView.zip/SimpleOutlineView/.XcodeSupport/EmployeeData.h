#import <Cocoa/Cocoa.h>
#import "xcc_general_include.h"

@interface EmployeeData : NSObject
@end
