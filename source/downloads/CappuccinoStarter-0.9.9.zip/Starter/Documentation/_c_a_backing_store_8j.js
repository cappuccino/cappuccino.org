var _c_a_backing_store_8j =
[
    [ "PIXEL", "_c_a_backing_store_8j.html#a8d2d227db347a0a996d0d01e374c6eeb", null ],
    [ "CABackingStoreGetContext", "_c_a_backing_store_8j.html#aa4548a0fd3852c314fdb3e21aa0aa897", null ],
    [ "if", "_c_a_backing_store_8j.html#ad2b049b1f6911d2ffffc0769dfe601e4", null ],
    [ "CABackingStoreSetSize", "_c_a_backing_store_8j.html#ac183987f6109f6f808a07d2522af5db9", null ],
    [ "else", "_c_a_backing_store_8j.html#a0544c3fe466e421738dae463968b70ba", null ]
];