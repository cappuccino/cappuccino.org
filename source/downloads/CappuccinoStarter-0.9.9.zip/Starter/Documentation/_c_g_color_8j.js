var _c_g_color_8j =
[
    [ "CFHashCode", "_c_g_color_8j.html#a71413947474ba53dba0e397a1b99d495", null ],
    [ "CGColorCreate", "_c_g_color_8j.html#af5e4c5b7c77b5b905e33ac78919055e6", null ],
    [ "CGColorCreateCopy", "_c_g_color_8j.html#a4c8841b109648695bb7c0370287badc1", null ],
    [ "CGColorCreateCopyWithAlpha", "_c_g_color_8j.html#abf31af54f73f9d7cb39642afd20f3b59", null ],
    [ "CGColorCreateGenericCMYK", "_c_g_color_8j.html#a3fa56c7529c0408b2f3b13816b310091", null ],
    [ "CGColorCreateGenericGray", "_c_g_color_8j.html#aa0ac3308c0d92fe178f086898faa76fe", null ],
    [ "CGColorCreateGenericRGB", "_c_g_color_8j.html#a2104701c6fe6b6ce377af75bd596a712", null ],
    [ "CGColorCreateWithPattern", "_c_g_color_8j.html#a7e6b723b378dc0f1126f9df39d736c90", null ],
    [ "CGColorEqualToColor", "_c_g_color_8j.html#a9b31b966e8d63a6f397b290b2fa65312", null ],
    [ "CGColorGetAlpha", "_c_g_color_8j.html#af409c7cc959399d9c19b11765c4aed39", null ],
    [ "CGColorGetColorSpace", "_c_g_color_8j.html#adf09adb2e44d393e0609538370b41f15", null ],
    [ "CGColorGetComponents", "_c_g_color_8j.html#ad87137e7bb52dc8195632efdfbed60a3", null ],
    [ "CGColorGetConstantColor", "_c_g_color_8j.html#ac68b08c4398af8e3f6f930a881e07e4f", null ],
    [ "CGColorGetNumberOfComponents", "_c_g_color_8j.html#ac24b7b4a49d6e5b2ae339de2e298c9a6", null ],
    [ "CGColorGetPattern", "_c_g_color_8j.html#a6daaa0e6750e246551184096b1b15860", null ],
    [ "CGColorRelease", "_c_g_color_8j.html#a86109ca29da45a145374dd4b2060c7e2", null ],
    [ "CGColorRetain", "_c_g_color_8j.html#a2472001c3e22caf783ecada5930231d2", null ],
    [ "CFTypeGlobalCount", "_c_g_color_8j.html#a4d1c90afcb24ea744a1eebe6c6c40b92", null ],
    [ "kCGColorBlack", "_c_g_color_8j.html#aef014c6bf09002137feea26ee9855462", null ],
    [ "kCGColorClear", "_c_g_color_8j.html#abad85cd72cee23fd405e1adf23712911", null ],
    [ "kCGColorWhite", "_c_g_color_8j.html#a001f642826bcf82291c7958917492d39", null ]
];