var _c_p_collection_view_8j =
[
    [ "<CPCollectionViewDelegate>", "protocol_c_p_collection_view_delegate-p.html", "protocol_c_p_collection_view_delegate-p" ],
    [ "CPCollectionViewAllowsMultipleSelectionKey", "_c_p_collection_view_8j.html#a6f5e8f1cf64010a5c736379a9b369173", null ],
    [ "CPCollectionViewBackgroundColorsKey", "_c_p_collection_view_8j.html#ac4545fc81a9a800b0fad4771ebad798e", null ],
    [ "CPCollectionViewDelegate_collectionView_acceptDrop_index_dropOperation_", "_c_p_collection_view_8j.html#a6f5f6ff6b174dde45b04c07b3be91b14", null ],
    [ "CPCollectionViewDelegate_collectionView_canDragItemsAtIndexes_withEvent_", "_c_p_collection_view_8j.html#ae0be4c01307bc89af7b9d9db16f69410", null ],
    [ "CPCollectionViewDelegate_collectionView_dataForItemsAtIndexes_forType_", "_c_p_collection_view_8j.html#a1f0036ca741d7bdfab8cf88ebae6cb85", null ],
    [ "CPCollectionViewDelegate_collectionView_didDoubleClickOnItemAtIndex_", "_c_p_collection_view_8j.html#a91a901f8dea4667dca5d4c7c0df8ad24", null ],
    [ "CPCollectionViewDelegate_collectionView_draggingViewForItemsAtIndexes_withEvent_offset", "_c_p_collection_view_8j.html#a86ccb38dc416753d3e58b65e5a96aa16", null ],
    [ "CPCollectionViewDelegate_collectionView_dragTypesForItemsAtIndexes_", "_c_p_collection_view_8j.html#af6d86eb19ec2389c7b840573a1cebaec", null ],
    [ "CPCollectionViewDelegate_collectionView_menuForItemAtIndex_", "_c_p_collection_view_8j.html#a606dce45f5b8bbfaf17a3ee0d3fe306e", null ],
    [ "CPCollectionViewDelegate_collectionView_validateDrop_proposedIndex_dropOperation_", "_c_p_collection_view_8j.html#ac7de21d562dc1812715a5704b7bd53e1", null ],
    [ "CPCollectionViewDelegate_collectionView_writeItemsAtIndexes_toPasteboard_", "_c_p_collection_view_8j.html#a12460bc1a0fad0fa752791db720e4d24", null ],
    [ "CPCollectionViewMaxItemSizeKey", "_c_p_collection_view_8j.html#a2a34f079aaa3baf03b3eff47e86ed820", null ],
    [ "CPCollectionViewMaxNumberOfColumnsKey", "_c_p_collection_view_8j.html#a90ebed379dea7007b1bb39ac8b093dbd", null ],
    [ "CPCollectionViewMaxNumberOfRowsKey", "_c_p_collection_view_8j.html#ae887c8873e981f2cee4645e7ee59c0fc", null ],
    [ "CPCollectionViewMinItemSizeKey", "_c_p_collection_view_8j.html#a441f38bb0b93ea62e27bd64e878b7b8c", null ],
    [ "CPCollectionViewSelectableKey", "_c_p_collection_view_8j.html#a4a21b2b086e445a2955b744347c3402a", null ],
    [ "CPCollectionViewVerticalMarginKey", "_c_p_collection_view_8j.html#a5fb05760157ca2a6150194f015684fb1", null ],
    [ "HORIZONTAL_MARGIN", "_c_p_collection_view_8j.html#a003be77c7cea09b503b8cfff73aef3b2", null ]
];