var _c_p_gradient_8j =
[
    [ "CPGradientDrawsAfterEndingLocation", "_c_p_gradient_8j.html#aebacb3d545cd753c173565b1bf5c7bbe", null ],
    [ "CPGradientDrawsBeforeStartingLocation", "_c_p_gradient_8j.html#ad3f6c12a20e61a954fc067c9c2341031", null ]
];