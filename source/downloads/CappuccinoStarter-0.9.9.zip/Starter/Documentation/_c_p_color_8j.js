var _c_p_color_8j =
[
    [ "CPColorPatternIsHorizontal", "_c_p_color_8j.html#a6a3a6ea559bd16018cf4baaf3b9cf5e6", null ],
    [ "CPColorPatternIsVertical", "_c_p_color_8j.html#a49e1857d611d9ddf6c0de040c7e25416", null ]
];