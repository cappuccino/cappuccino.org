var _c_p_array_controller_8j =
[
    [ "CPArrayControllerAlwaysUsesMultipleValuesMarker", "_c_p_array_controller_8j.html#a3c35fe34105752a1f2bf1a4fd2de84b7", null ],
    [ "CPArrayControllerAutomaticallyRearrangesObjects", "_c_p_array_controller_8j.html#a023680c7bb4ee21750511a884a7e8bbc", null ],
    [ "CPArrayControllerAvoidsEmptySelection", "_c_p_array_controller_8j.html#ad0386605fca84a85e9b0e04e4f716358", null ],
    [ "CPArrayControllerClearsFilterPredicateOnInsertion", "_c_p_array_controller_8j.html#ae8653b7dbf656c60994ca5a062850a1f", null ],
    [ "CPArrayControllerFilterRestrictsInsertion", "_c_p_array_controller_8j.html#abeda110557b03df63cfc09ea1a4a7000", null ],
    [ "CPArrayControllerPreservesSelection", "_c_p_array_controller_8j.html#a63006c88abd72a7803c2c415ecbbeed0", null ],
    [ "CPArrayControllerSelectsInsertedObjects", "_c_p_array_controller_8j.html#ab2e339de1890c71746576768712858f6", null ]
];